/************** -*-C-*- *********************************************
 * $Id$
 *                                                                  *
 *       AMESim C code for cosimulation written by code generator.  *

                                 DFN_Model_Verification_
 *
 *******************************************************************/

#include "DFN_Model_Verification_.h"
#include "ame_interfaces.h"

#include <assert.h>
#include <stdio.h>

#if !defined(AME_DS1006)
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#endif

#ifndef AME_DS1006
#include <fcntl.h>
#endif

#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <setjmp.h>

#ifdef _WIN32
#ifndef WIN32
#define WIN32
#endif
#endif

#include "ameutils.h"
#include "codegen_ameutils_public.h"
#include "itf_amesubintf_public.h"

#if defined (WIN32) || defined(XPCMSVISUALC)
#include <io.h>
#elif !defined(AME_DS1006)
#include <unistd.h>
#endif

#if defined(_WINDOWS) || defined(_WIN32) || defined(WIN32)
#define DLLEXPORTDEF __declspec(dllexport)
#else
#define DLLEXPORTDEF
#endif

#if defined (RTLAB) || defined(AME_DS1006) ||  defined(AME_DS1007) || defined(LABCAR) || defined(AME_ADX) || defined(AME_HWA) || defined(RT) ||defined(AMEVERISTAND)
#ifdef DLLEXPORTDEF
#undef DLLEXPORTDEF
#endif
#define DLLEXPORTDEF
#endif

/* If we are in Simulink we should set things up for a AMEMULTIDLL (only static symbols) */
#if defined(AME_CS_SIMULINK) || defined(AME_ME_SIMULINK)
#ifndef AMEMULTIDLL
#define AMEMULTIDLL
#endif
#endif

/* If we are in Veristand we should set things up for a AMEMULTIDLL (only static symbols) */
#ifdef AMEVERISTAND
#ifndef AMEMULTIDLL
#define AMEMULTIDLL
#endif
#endif

/* avoid globally exported functions - required for exporting several models in one executable */
#if defined AMEMULTIDLL
#define DLLEXPORTDEF_OR_STATIC static
#else
#define DLLEXPORTDEF_OR_STATIC DLLEXPORTDEF
#endif

#if defined CREATING_STATIC_LIB
#define DLLEXPORTDEF_OR_EXTERN extern
#else
#define DLLEXPORTDEF_OR_EXTERN DLLEXPORTDEF
#endif

#define TIME_ROUNDOFF 1.0e-10
#define TLAST_MIN     -1E30

#if defined(FMICS1) || defined(FMICS2) || defined(FMICS3) || defined(FMIME1) || defined(FMIME2)
#ifdef FMIX
#undef FMIX
#endif
#define FMI
#define MODEL_IDENTIFIER         DFN_Model_Verification_
#define MODEL_IDENTIFIER_STRING "DFN_Model_Verification_"
#endif

/* *****************************************************************

   code inserted by AMESim

   *****************************************************************/

#define AMEVERSION                  202410000
#define SUB_LENGTH                  63

static const char soldToId[] = "4553207";

/**** Model structure definition ****/
/* Structural definition of the model */
#define AME_MODEL_ISEXPLICIT        1

/* Number of explicit declared states  */
#define AME_NBOF_EXPLICIT_STATE     232

/* Number of implicit declared states  */
#define AME_NBOF_IMPLICIT_STATE_DECLARED  0
#define AME_NBOF_IMPLICIT_STATE_GENERATED 0
#define AME_NBOF_IMPLICIT_STATE           0

/* Number of discrete declared states  */
#define AME_NBOF_DISCRETE_STATE     2

/* Total number of states manipulated by the Amesim solver including generated states */
#define AME_NBOF_SOLVER_STATES      232

#define AME_NBOF_PARAMS             312
#define AME_NBOF_REAL_PARAMS        38
#define AME_NBOF_INT_PARAMS         19
#define AME_NBOF_TEXT_PARAMS        17
#define AME_NBOF_CSTATE_PARAMS      232
#define AME_NBOF_DSTATE_PARAMS      2
#define AME_NBOF_FIXED_VAR_PARAMS   4

#define AME_NBOF_VARS               769
#define AME_NBOF_INPUTS             0
#define AME_NBOF_OUTPUTS            0

#define AME_NBOF_REAL_STORES        2
#define AME_NBOF_INT_STORES         4
#define AME_NBOF_POINTER_STORES     1

#define AME_SIZEOF_DBWORK_ARRAY     0

#define AME_NB_VAR_INFO             116

#define AME_NB_NETWORK              0

#define AME_NB_SUBMODEL_REF         10

static const S_AMEModelDef GmodelDef = {
   AME_MODEL_ISEXPLICIT,
   AME_NBOF_EXPLICIT_STATE,
   AME_NBOF_IMPLICIT_STATE_DECLARED,
   AME_NBOF_IMPLICIT_STATE_GENERATED,
   AME_NBOF_DISCRETE_STATE,
   AME_NBOF_VARS,
   AME_NBOF_PARAMS,
   AME_NBOF_REAL_PARAMS,
   AME_NBOF_INT_PARAMS,
   AME_NBOF_TEXT_PARAMS,
   AME_NBOF_CSTATE_PARAMS,
   AME_NBOF_DSTATE_PARAMS,
   AME_NBOF_FIXED_VAR_PARAMS,
   AME_NBOF_INPUTS,
   AME_NBOF_OUTPUTS,
   AME_NBOF_REAL_STORES,
   AME_NBOF_INT_STORES,
   AME_NBOF_POINTER_STORES,
   AME_SIZEOF_DBWORK_ARRAY,
   AME_NB_VAR_INFO,
   AME_NB_NETWORK,
   AME_NB_SUBMODEL_REF
};


static const char **GinputVarTitles = NULL;
static const char **GoutputVarTitles = NULL;

/**** Parameters structure definition ****/

#define NB_SUBMODELNAME       6
static const char* GsubmodelNameArray[NB_SUBMODELNAME] = {
     "ESSBATCP2D01V01 instance 1"
   , "EBVT01 instance 1"
   , "EB3N05 instance 1"
   , "CONS00 instance 1"
   , "THTS1 instance 1"
   , "STOP0 instance 1"
};

static const S_AMEParamInfo GParamInfo[312] = {
     {E_Real_Param           , E_Expression_Param, 0, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 1, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 2, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 3, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 4, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 5, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 6, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 7, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 8, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 9, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 10, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 11, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 12, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 13, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 14, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 15, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 16, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 17, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 18, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 19, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 20, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 21, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 22, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 23, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 24, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 25, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 26, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 27, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 28, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 29, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 30, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 31, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 32, -1, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 33, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 0, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 1, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 2, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 3, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 4, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 5, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 6, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 7, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 8, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 9, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 10, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 11, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 12, -1, 0, 0}
   , {E_Int_Param            , E_Expression_Param, 13, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 0, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 1, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 2, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 3, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 4, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 5, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 6, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 7, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 8, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 9, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 10, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 11, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 12, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 13, -1, 0, 0}
   , {E_Text_Param           , E_Expression_Param, 14, -1, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 0, 11, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 1, 12, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 2, 13, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 3, 14, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 4, 15, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 5, 16, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 6, 17, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 7, 18, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 8, 19, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 9, 20, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 10, 21, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 11, 22, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 12, 23, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 13, 24, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 14, 25, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 15, 26, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 16, 27, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 17, 28, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 18, 29, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 19, 30, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 20, 31, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 21, 32, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 22, 33, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 23, 34, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 24, 35, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 25, 36, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 26, 37, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 27, 38, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 28, 39, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 29, 40, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 30, 41, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 31, 42, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 32, 43, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 33, 44, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 34, 45, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 35, 46, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 36, 47, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 37, 48, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 38, 49, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 39, 50, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 40, 51, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 41, 52, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 42, 53, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 43, 54, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 44, 55, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 45, 56, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 46, 57, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 47, 58, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 48, 59, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 49, 60, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 50, 61, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 51, 62, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 52, 63, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 53, 64, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 54, 65, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 55, 66, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 56, 67, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 57, 68, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 58, 69, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 59, 70, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 60, 71, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 61, 72, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 62, 73, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 63, 74, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 64, 75, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 65, 76, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 66, 77, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 67, 78, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 68, 79, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 69, 80, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 70, 81, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 71, 82, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 72, 83, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 73, 84, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 74, 85, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 75, 86, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 76, 87, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 77, 88, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 78, 89, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 79, 90, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 80, 91, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 81, 92, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 82, 93, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 83, 94, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 84, 95, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 85, 96, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 86, 97, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 87, 98, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 88, 99, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 89, 100, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 90, 101, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 91, 102, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 92, 103, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 93, 104, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 94, 105, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 95, 106, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 96, 107, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 97, 108, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 98, 109, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 99, 110, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 100, 111, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 101, 112, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 102, 113, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 103, 114, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 104, 115, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 105, 116, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 106, 117, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 107, 118, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 108, 119, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 109, 120, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 110, 121, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 111, 122, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 112, 123, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 113, 124, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 114, 125, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 115, 126, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 116, 127, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 117, 128, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 118, 129, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 119, 130, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 120, 131, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 121, 132, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 122, 133, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 123, 134, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 124, 135, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 125, 136, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 126, 137, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 127, 138, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 128, 139, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 129, 140, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 130, 141, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 131, 142, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 132, 143, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 133, 144, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 134, 145, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 135, 146, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 136, 147, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 137, 148, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 138, 149, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 139, 150, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 140, 151, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 141, 152, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 142, 153, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 143, 154, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 144, 155, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 145, 156, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 146, 157, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 147, 158, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 148, 159, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 149, 160, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 150, 161, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 151, 162, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 152, 163, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 153, 164, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 154, 165, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 155, 166, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 156, 167, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 157, 168, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 158, 169, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 159, 170, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 160, 171, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 161, 172, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 162, 173, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 163, 174, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 164, 175, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 165, 176, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 166, 177, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 167, 178, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 168, 179, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 169, 180, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 170, 181, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 171, 182, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 172, 183, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 173, 184, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 174, 185, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 175, 186, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 176, 187, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 177, 188, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 178, 189, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 179, 190, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 180, 191, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 181, 192, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 182, 193, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 183, 194, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 184, 195, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 185, 196, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 186, 197, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 187, 198, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 188, 199, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 189, 200, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 190, 201, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 191, 202, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 192, 203, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 193, 204, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 194, 205, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 195, 206, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 196, 207, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 197, 208, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 198, 209, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 199, 210, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 200, 211, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 201, 212, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 202, 213, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 203, 214, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 204, 215, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 205, 216, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 206, 217, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 207, 218, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 208, 219, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 209, 220, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 210, 221, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 211, 222, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 212, 223, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 213, 224, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 214, 225, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 215, 226, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 216, 227, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 217, 228, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 218, 229, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 219, 230, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 220, 231, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 221, 232, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 222, 233, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 223, 234, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 224, 235, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 225, 236, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 226, 237, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 227, 238, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 228, 239, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 229, 240, 0, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 230, 322, 0, 0}
   , {E_Real_Param           , E_Expression_Param, 34, -1, 1, 0}
   , {E_Real_Param           , E_Expression_Param, 35, -1, 1, 0}
   , {E_Int_Param            , E_Expression_Param, 14, -1, 1, 0}
   , {E_FixedVar_Param       , E_Expression_Param, 0, 759, 1, 0}
   , {E_FixedVar_Param       , E_Expression_Param, 1, 756, 1, 0}
   , {E_FixedVar_Param       , E_Expression_Param, 2, 762, 1, 0}
   , {E_Real_Param           , E_Expression_Param, 36, -1, 2, 0}
   , {E_ContinuousState_Param, E_Expression_Param, 231, 758, 2, 0}
   , {E_Real_Param           , E_Expression_Param, 37, -1, 3, 1}
   , {E_DiscreteState_Param  , E_Expression_Param, 0, 765, 3, 0}
   , {E_FixedVar_Param       , E_Expression_Param, 3, 766, 4, 0}
   , {E_Int_Param            , E_Expression_Param, 15, -1, 5, 0}
   , {E_Int_Param            , E_Expression_Param, 16, -1, 5, 0}
   , {E_Int_Param            , E_Expression_Param, 17, -1, 5, 0}
   , {E_Int_Param            , E_Expression_Param, 18, -1, 5, 0}
   , {E_Text_Param           , E_Expression_Param, 15, -1, 5, 0}
   , {E_Text_Param           , E_Expression_Param, 16, -1, 5, 0}
   , {E_DiscreteState_Param  , E_Expression_Param, 1, 768, 5, 0}
};
#define NB_REAL_TUNABLE_PARAM 1
static const int GRealTunableParam[NB_REAL_TUNABLE_PARAM][2] = {
     {37, 765}
};
#define NB_INT_TUNABLE_PARAM 0

static const int GcontStateVarNum[AME_NBOF_EXPLICIT_STATE] = {
     11, 12, 13, 14, 15, 16, 17, 18, 19, 20
   , 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
   , 31, 32, 33, 34, 35, 36, 37, 38, 39, 40
   , 41, 42, 43, 44, 45, 46, 47, 48, 49, 50
   , 51, 52, 53, 54, 55, 56, 57, 58, 59, 60
   , 61, 62, 63, 64, 65, 66, 67, 68, 69, 70
   , 71, 72, 73, 74, 75, 76, 77, 78, 79, 80
   , 81, 82, 83, 84, 85, 86, 87, 88, 89, 90
   , 91, 92, 93, 94, 95, 96, 97, 98, 99, 100
   , 101, 102, 103, 104, 105, 106, 107, 108, 109, 110
   , 111, 112, 113, 114, 115, 116, 117, 118, 119, 120
   , 121, 122, 123, 124, 125, 126, 127, 128, 129, 130
   , 131, 132, 133, 134, 135, 136, 137, 138, 139, 140
   , 141, 142, 143, 144, 145, 146, 147, 148, 149, 150
   , 151, 152, 153, 154, 155, 156, 157, 158, 159, 160
   , 161, 162, 163, 164, 165, 166, 167, 168, 169, 170
   , 171, 172, 173, 174, 175, 176, 177, 178, 179, 180
   , 181, 182, 183, 184, 185, 186, 187, 188, 189, 190
   , 191, 192, 193, 194, 195, 196, 197, 198, 199, 200
   , 201, 202, 203, 204, 205, 206, 207, 208, 209, 210
   , 211, 212, 213, 214, 215, 216, 217, 218, 219, 220
   , 221, 222, 223, 224, 225, 226, 227, 228, 229, 230
   , 231, 232, 233, 234, 235, 236, 237, 238, 239, 240
   , 322, 758
};

static const int GdiscStateVarNum[AME_NBOF_DSTATE_PARAMS] = {
     765, 768
};

static const int *GInputVarNum = NULL;

static const double *GInputStartValues = NULL;

static const int *GOutputVarNum = NULL;

static const int GFixedVarNum[AME_NBOF_FIXED_VAR_PARAMS] = {
     759, 756, 762, 766
};

#define PS0 (&amesys->pModel->pointerStoreArray[0])
#define RP0 (&amesys->pModel->realParamArray[0])
#define IP0 (&amesys->pModel->integerParamArray[0])
#define TP0 (&amesys->pModel->textParamArray[0])
#define RP3 (&amesys->pModel->realParamArray[34])
#define IP3 (&amesys->pModel->integerParamArray[14])
#define IS4 (&amesys->pModel->intStoreArray[0])
#define RP4 (&amesys->pModel->realParamArray[36])
#define RP5 (&amesys->pModel->realParamArray[37])
#define RS9 (&amesys->pModel->realStoreArray[0])
#define IS9 (&amesys->pModel->intStoreArray[1])
#define IP9 (&amesys->pModel->integerParamArray[15])
#define TP9 (&amesys->pModel->textParamArray[15])


static const S_AMEVariableInfo GVarInfo[AME_NB_VAR_INFO] = {
   { 0, 1, 1, 1, "EB3N05", "V2" }
  ,{ 1, 1, 1, 1, "ESSBATCP2D01V01", "I1" }
  ,{ 2, 1, 1, 1, "EB3N03", "I3" }
  ,{ 3, 1, 1, 1, "ESSBATCP2D01V01", "V2" }
  ,{ 4, 1, 1, 1, "THCS1", "outt" }
  ,{ 5, 1, 1, 1, "ESSBATCP2D01V01", "dh3" }
  ,{ 6, 1, 1, 1, "ESSBATCP2D01V01", "soc" }
  ,{ 7, 1, 1, 1, "ESSBATCP2D01V01", "I" }
  ,{ 8, 1, 1, 1, "ESSBATCP2D01V01", "U" }
  ,{ 9, 0, 1, 1, "ESSBATCP2D01V01", "Uunfilt" }
  ,{ 10, 0, 1, 1, "ESSBATCP2D01V01", "Uunfilt2" }
  ,{ 11, 1, 10, 1, "ESSBATCP2D01V01", "poscs1_1" }
  ,{ 21, 1, 10, 1, "ESSBATCP2D01V01", "poscs2_1" }
  ,{ 31, 1, 10, 1, "ESSBATCP2D01V01", "poscs3_1" }
  ,{ 41, 1, 10, 1, "ESSBATCP2D01V01", "poscs4_1" }
  ,{ 51, 1, 10, 1, "ESSBATCP2D01V01", "poscs5_1" }
  ,{ 61, 1, 10, 1, "ESSBATCP2D01V01", "poscs6_1" }
  ,{ 71, 1, 10, 1, "ESSBATCP2D01V01", "poscs7_1" }
  ,{ 81, 1, 10, 1, "ESSBATCP2D01V01", "poscs8_1" }
  ,{ 91, 1, 10, 1, "ESSBATCP2D01V01", "poscs9_1" }
  ,{ 101, 1, 10, 1, "ESSBATCP2D01V01", "poscs10_1" }
  ,{ 111, 1, 10, 1, "ESSBATCP2D01V01", "negcs1_1" }
  ,{ 121, 1, 10, 1, "ESSBATCP2D01V01", "negcs2_1" }
  ,{ 131, 1, 10, 1, "ESSBATCP2D01V01", "negcs3_1" }
  ,{ 141, 1, 10, 1, "ESSBATCP2D01V01", "negcs4_1" }
  ,{ 151, 1, 10, 1, "ESSBATCP2D01V01", "negcs5_1" }
  ,{ 161, 1, 10, 1, "ESSBATCP2D01V01", "negcs6_1" }
  ,{ 171, 1, 10, 1, "ESSBATCP2D01V01", "negcs7_1" }
  ,{ 181, 1, 10, 1, "ESSBATCP2D01V01", "negcs8_1" }
  ,{ 191, 1, 10, 1, "ESSBATCP2D01V01", "negcs9_1" }
  ,{ 201, 1, 10, 1, "ESSBATCP2D01V01", "negcs10_1" }
  ,{ 211, 1, 30, 1, "ESSBATCP2D01V01", "eleCs_1" }
  ,{ 241, 1, 10, 1, "ESSBATCP2D01V01", "posUeq_1" }
  ,{ 251, 1, 10, 1, "ESSBATCP2D01V01", "negUeq_1" }
  ,{ 261, 1, 30, 1, "ESSBATCP2D01V01", "eleUeq_1" }
  ,{ 291, 1, 1, 1, "ESSBATCP2D01V01", "posUeqmean" }
  ,{ 292, 1, 1, 1, "ESSBATCP2D01V01", "negUeqmean" }
  ,{ 293, 1, 1, 1, "ESSBATCP2D01V01", "posUeqav" }
  ,{ 294, 1, 1, 1, "ESSBATCP2D01V01", "negUeqav" }
  ,{ 295, 1, 1, 1, "ESSBATCP2D01V01", "posx100" }
  ,{ 296, 1, 1, 1, "ESSBATCP2D01V01", "negx100" }
  ,{ 297, 1, 10, 1, "ESSBATCP2D01V01", "posx_1" }
  ,{ 307, 1, 10, 1, "ESSBATCP2D01V01", "negx_1" }
  ,{ 317, 1, 1, 1, "ESSBATCP2D01V01", "posxmean" }
  ,{ 318, 1, 1, 1, "ESSBATCP2D01V01", "negxmean" }
  ,{ 319, 1, 1, 1, "ESSBATCP2D01V01", "dUdT" }
  ,{ 320, 1, 1, 1, "ESSBATCP2D01V01", "ocv" }
  ,{ 321, 1, 1, 1, "ESSBATCP2D01V01", "ocvav" }
  ,{ 322, 1, 1, 1, "ESSBATCP2D01V01", "hystfact" }
  ,{ 323, 1, 10, 1, "ESSBATCP2D01V01", "posDsc1_1" }
  ,{ 333, 1, 10, 1, "ESSBATCP2D01V01", "posDsc2_1" }
  ,{ 343, 1, 10, 1, "ESSBATCP2D01V01", "posDsc3_1" }
  ,{ 353, 1, 10, 1, "ESSBATCP2D01V01", "posDsc4_1" }
  ,{ 363, 1, 10, 1, "ESSBATCP2D01V01", "posDsc5_1" }
  ,{ 373, 1, 10, 1, "ESSBATCP2D01V01", "posDsc6_1" }
  ,{ 383, 1, 10, 1, "ESSBATCP2D01V01", "posDsc7_1" }
  ,{ 393, 1, 10, 1, "ESSBATCP2D01V01", "posDsc8_1" }
  ,{ 403, 1, 10, 1, "ESSBATCP2D01V01", "posDsc9_1" }
  ,{ 413, 1, 10, 1, "ESSBATCP2D01V01", "posDsc10_1" }
  ,{ 423, 1, 10, 1, "ESSBATCP2D01V01", "negDsc1_1" }
  ,{ 433, 1, 10, 1, "ESSBATCP2D01V01", "negDsc2_1" }
  ,{ 443, 1, 10, 1, "ESSBATCP2D01V01", "negDsc3_1" }
  ,{ 453, 1, 10, 1, "ESSBATCP2D01V01", "negDsc4_1" }
  ,{ 463, 1, 10, 1, "ESSBATCP2D01V01", "negDsc5_1" }
  ,{ 473, 1, 10, 1, "ESSBATCP2D01V01", "negDsc6_1" }
  ,{ 483, 1, 10, 1, "ESSBATCP2D01V01", "negDsc7_1" }
  ,{ 493, 1, 10, 1, "ESSBATCP2D01V01", "negDsc8_1" }
  ,{ 503, 1, 10, 1, "ESSBATCP2D01V01", "negDsc9_1" }
  ,{ 513, 1, 10, 1, "ESSBATCP2D01V01", "negDsc10_1" }
  ,{ 523, 1, 30, 1, "ESSBATCP2D01V01", "eleDeff_1" }
  ,{ 553, 1, 30, 1, "ESSBATCP2D01V01", "elekapac_1" }
  ,{ 583, 1, 30, 1, "ESSBATCP2D01V01", "eletplus_1" }
  ,{ 613, 1, 30, 1, "ESSBATCP2D01V01", "jf_1" }
  ,{ 643, 1, 1, 1, "ESSBATCP2D01V01", "sloss" }
  ,{ 644, 1, 1, 1, "ESSBATCP2D01V01", "hloss" }
  ,{ 645, 1, 30, 1, "ESSBATCP2D01V01", "phie_1" }
  ,{ 675, 1, 10, 1, "ESSBATCP2D01V01", "negetak_1" }
  ,{ 685, 1, 1, 1, "ESSBATCP2D01V01", "negsigmaEff" }
  ,{ 686, 1, 1, 1, "ESSBATCP2D01V01", "possigmaEff" }
  ,{ 687, 1, 10, 1, "ESSBATCP2D01V01", "posetak_1" }
  ,{ 697, 1, 10, 1, "ESSBATCP2D01V01", "negdeltaphi_1" }
  ,{ 707, 1, 10, 1, "ESSBATCP2D01V01", "posdeltaphi_1" }
  ,{ 717, 0, 10, 1, "ESSBATCP2D01V01", "dnegdeltaphi_1" }
  ,{ 727, 0, 10, 1, "ESSBATCP2D01V01", "dposdeltaphi_1" }
  ,{ 737, 1, 1, 1, "ESSBATCP2D01V01", "posmeandeltaphi" }
  ,{ 738, 1, 1, 1, "ESSBATCP2D01V01", "negmeandeltaphi" }
  ,{ 739, 1, 1, 1, "ESSBATCP2D01V01", "posmeanUeq" }
  ,{ 740, 1, 1, 1, "ESSBATCP2D01V01", "negmeanUeq" }
  ,{ 741, 1, 1, 1, "ESSBATCP2D01V01", "posmeanetaohm" }
  ,{ 742, 1, 1, 1, "ESSBATCP2D01V01", "negmeanetaohm" }
  ,{ 743, 1, 1, 1, "ESSBATCP2D01V01", "posmeanetakin" }
  ,{ 744, 1, 1, 1, "ESSBATCP2D01V01", "negmeanetakin" }
  ,{ 745, 1, 1, 1, "ESSBATCP2D01V01", "elemeanetaohm" }
  ,{ 746, 1, 1, 1, "ESSBATCP2D01V01", "elemeanetadiff" }
  ,{ 747, 1, 1, 1, "ESSBATCP2D01V01", "poskT" }
  ,{ 748, 1, 1, 1, "ESSBATCP2D01V01", "negkT" }
  ,{ 749, 1, 1, 1, "EB3N03", "V2" }
  ,{ 750, 1, 1, 1, "EBAS03", "I1" }
  ,{ 751, 1, 1, 1, "EB3N05", "V3" }
  ,{ 752, 1, 1, 1, "EBAS03", "I2" }
  ,{ 753, 1, 1, 1, "CONS00", "out" }
  ,{ 754, 1, 1, 1, "EBAS03", "U" }
  ,{ 755, 1, 1, 1, "EBAS03", "I" }
  ,{ 756, 1, 1, 1, "EBVT01", "I3" }
  ,{ 757, 1, 1, 1, "EB3N03", "V1" }
  ,{ 758, 1, 1, 1, "EB3N05", "V1" }
  ,{ 759, 1, 1, 1, "EBVT01", "I1" }
  ,{ 760, 1, 1, 1, "EBVT01", "vsig" }
  ,{ 761, 1, 1, 1, "EBVT01", "U" }
  ,{ 762, 1, 1, 1, "EBVT01", "I" }
  ,{ 763, 1, 1, 1, "EB3N05", "Ileak" }
  ,{ 764, 0, 1, 1, "EB3N05", "powerCelec" }
  ,{ 765, 1, 1, 1, "CONS00", "k0GEN" }
  ,{ 766, 1, 1, 1, "THTS1", "t1" }
  ,{ 767, 1, 1, 1, "THCS1", "ohfs" }
  ,{ 768, 1, 1, 1, "STOP0", "xref" }
};

#if !defined(AME_IMPLICIT_MODEL_ACCEPTED) && (AME_MODEL_ISEXPLICIT == 0)
#error "Implicit model not supported for the current interface."
#endif


/* ============================================================== */
/* If the interface needs linearisation (cosim and Amesim) */

#ifndef AME_NO_LA
#ifndef AME_NEED_LINEAR_ANALYSIS
#define AME_NEED_LINEAR_ANALYSIS
#endif
#endif

#if( AME_MODEL_ISEXPLICIT == 1)
#define AMEfuncPerturb LPerturbIfNecessary
#else
#define AMEfuncPerturb DPerturbIfNecessary
#endif

#ifdef AME_ADVANCEDDEBUG
static void AME_POST_SUBMODCALL_WITH_DISCON(AMESIMSYSTEM *amesys, int *flag, int *sflag, int *oflag, int *panic, char *submodelname, int instancenum)
{
   if(*sflag < 3)*sflag = getnfg_();
#ifdef AME_NEED_LINEAR_ANALYSIS
   if(*flag == 5)
   {
      AMEfuncPerturb(amesys, flag);
   }
   else if(*oflag != 5)
   {
      resdis(amesys, flag, sflag, oflag, submodelname, instancenum, panic);
   }
#else
   resdis(amesys, flag, sflag, oflag, submodelname, instancenum, panic);
#endif
}

static void AME_POST_SUBMODCALL_NO_DISCON(AMESIMSYSTEM *amesys, int *flag)
{
#ifdef AME_NEED_LINEAR_ANALYSIS
   if(*flag == 5)
   {
      AMEfuncPerturb(amesys, flag);
   }
#endif
}
#endif


#ifndef AME_ADVANCEDDEBUG
#ifdef AME_NEED_LINEAR_ANALYSIS
/* Typically for normal runs and cosim */
#define AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,sflag,oflag,panic,submodelname,instancenum) if(*sflag < 3)*sflag = getnfg_(); if(*flag == 5) AMEfuncPerturb(amesys, flag); else if(*oflag != 5) resdis(amesys, flag, sflag, oflag, submodelname, instancenum, panic)
#define AME_POST_SUBMODCALL_NO_DISCON(amesys,flag) if(*flag == 5) AMEfuncPerturb(amesys, flag)
#else
/* Typically for code exchange (simulink for instance) */
#define AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,sflag,oflag,panic,submodelname,instancenum) if(*sflag < 3)*sflag = getnfg_(); resdis(amesys, flag, sflag, oflag,submodelname,instancenum,panic)
#define AME_POST_SUBMODCALL_NO_DISCON(amesys,flag)
#endif
#endif

#ifdef AMERT
/* We dont need LA nor resdis for real-time - so set them to (almost) empty macros. (reset sflag to orig value "oflag") */
#undef AME_POST_SUBMODCALL_WITH_DISCON
#undef AME_POST_SUBMODCALL_NO_DISCON
#define AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,sflag,oflag,panic,submodelname,instancenum) *sflag = *oflag
#define AME_POST_SUBMODCALL_NO_DISCON(amesys,flag)
#endif

/* ============================================================== */

#ifdef AMERT
double IL_DFN_Model_Verification_step_ratio=0;
#endif

#ifdef AME_MEMORY_ACCESS_RT_EXPORT
/* For memory access in case of RT target such as dSpace targets */
#include "DFN_Model_Verification_.export.h"

static void RT_Get_Watch_Var(AMESIMSYSTEM *amesys)
{
#if (NB_WATCH_VAR>0)
   int i;

   for(i=0; i<NB_WATCH_VAR; i++) {
      RT_Export_Vars[i] = amesys->v[RT_Watch_Vars_Idx[i]];
   }
#endif
}

static void RT_Get_Watch_Param(AMESIMSYSTEM *amesys)
{
#if (NB_WATCH_REAL_PARAM>0) || (NB_WATCH_INT_PARAM>0)
   int i;

   for(i=0; i<NB_WATCH_REAL_PARAM; i++) {
      RT_Export_RealParam[i] = amesys->pModel->realParamArray[RT_Watch_RP_Idx[i]];
   }
   for(i=0; i<NB_WATCH_INT_PARAM; i++) {
      RT_Export_IntParam[i] = amesys->pModel->integerParamArray[RT_Watch_IP_Idx[i]];
   }
#endif
}

static void RT_Set_Watch_Param(AMESIMSYSTEM *amesys)
{
#if (NB_WATCH_REAL_PARAM>0) || (NB_WATCH_INT_PARAM>0)
   int i;

   for(i=0; i<NB_WATCH_REAL_PARAM; i++) {
      amesys->pModel->realParamArray[RT_Watch_RP_Idx[i]] = RT_Export_RealParam[i];
   }
   for(i=0; i<NB_WATCH_INT_PARAM; i++) {
      amesys->pModel->integerParamArray[RT_Watch_IP_Idx[i]] = RT_Export_IntParam[i];
   }
#endif
}

#endif

#ifdef AME_INPUT_IN_MEMORY
#include "DFN_Model_Verification_.sim.h"
#endif

#if( AME_MODEL_ISEXPLICIT == 0 )
#define LRW (40+9*AME_NBOF_SOLVER_STATES+AME_NBOF_SOLVER_STATES*AME_NBOF_SOLVER_STATES)
#define LIW (21+AME_NBOF_SOLVER_STATES)
#endif

// Submodel ESSBATCP2D01V01 . 1
// variable I1 (Duplicate var)
static const int EVIA_V0[7] = {1, -1, 0, -1, 1, 1, 1};
// variable V1 (Basic var)
static const int EVIA_V1[7] = {0, -1, 1, -1, 1, 1, 1};
// variable V2 (Oneline var)
static const int EVIA_V2[7] = {3, -1, 2, -1, 1, 1, 1};
// variable I2 (Basic var)
static const int EVIA_V3[7] = {2, -1, 3, -1, 1, 1, 1};
// variable dh3 (Basic var)
static const int EVIA_V4[7] = {5, -1, 4, -1, 1, 1, 1};
// variable T3 (Basic var)
static const int EVIA_V5[7] = {4, -1, 5, -1, 1, 1, 1};
// Submodel CONS00 . 1
// variable out (Basic var)
static const int EVIA_V6[7] = {753, -1, 6, -1, 1, 1, 1};
// Submodel THCS1 . 1
// variable its (Basic var)
static const int EVIA_V7[7] = {766, -1, 7, -1, 1, 1, 1};
// variable ohfs (Duplicate var)
static const int EVIA_V8[7] = {767, -1, 8, -1, 1, 1, 1};
// variable outt (Duplicate var)
static const int EVIA_V9[7] = {4, -1, 9, -1, 1, 1, 1};
// variable ihfs (Basic var)
static const int EVIA_V10[7] = {5, -1, 10, -1, 1, 1, 1};
// Submodel THTS1 . 1
// variable t1 (Fixed var)
static const int EVIA_V11[7] = {766, -1, 11, -1, 1, 1, 1};
// Submodel EBAS03 . 1
// variable I1 (Duplicate var)
static const int EVIA_V12[7] = {750, -1, 12, -1, 1, 1, 1};
// variable V1 (Basic var)
static const int EVIA_V13[7] = {749, -1, 13, -1, 1, 1, 1};
// variable I2 (Duplicate var)
static const int EVIA_V14[7] = {752, -1, 14, -1, 1, 1, 1};
// variable V2 (Basic var)
static const int EVIA_V15[7] = {751, -1, 15, -1, 1, 1, 1};
// variable I3 (Basic var)
static const int EVIA_V16[7] = {753, -1, 16, -1, 1, 1, 1};
// Submodel EB3N03 . 1
// variable V1 (Duplicate var)
static const int EVIA_V17[7] = {757, -1, 17, -1, 1, 1, 1};
// variable I1 (Basic var)
static const int EVIA_V18[7] = {756, -1, 18, -1, 1, 1, 1};
// variable V2 (Duplicate var)
static const int EVIA_V19[7] = {749, -1, 19, -1, 1, 1, 1};
// variable I2 (Basic var)
static const int EVIA_V20[7] = {750, -1, 20, -1, 1, 1, 1};
// variable I3 (Oneline var)
static const int EVIA_V21[7] = {2, -1, 21, -1, 1, 1, 1};
// variable V3 (Basic var)
static const int EVIA_V22[7] = {3, -1, 22, -1, 1, 1, 1};
// Submodel EB3N05 . 1
// variable V1 (Explicit state)
static const int EVIA_V23[7] = {758, 231, 23, 24, 1, 1, 1};
// variable I1 (Basic var)
static const int EVIA_V24[7] = {759, -1, 25, -1, 1, 1, 1};
// variable V2 (Duplicate var)
static const int EVIA_V25[7] = {0, -1, 26, -1, 1, 1, 1};
// variable I2 (Basic var)
static const int EVIA_V26[7] = {1, -1, 27, -1, 1, 1, 1};
// variable V3 (Duplicate var)
static const int EVIA_V27[7] = {751, -1, 28, -1, 1, 1, 1};
// variable I3 (Basic var)
static const int EVIA_V28[7] = {752, -1, 29, -1, 1, 1, 1};
// Submodel EBVT01 . 1
// variable I1 (Fixed var)
static const int EVIA_V29[7] = {759, -1, 30, -1, 1, 1, 1};
// variable V1 (Basic var)
static const int EVIA_V30[7] = {758, -1, 31, -1, 1, 1, 1};
// variable vsig (Basic var)
static const int EVIA_V31[7] = {760, -1, 32, -1, 1, 1, 1};
// variable I3 (Fixed var)
static const int EVIA_V32[7] = {756, -1, 33, -1, 1, 1, 1};
// variable V3 (Basic var)
static const int EVIA_V33[7] = {757, -1, 34, -1, 1, 1, 1};
// Submodel SSINK . 1
// variable sink (Basic var)
static const int EVIA_V34[7] = {767, -1, 35, -1, 1, 1, 1};
// Submodel STOP0 . 1
// variable x (Basic var)
static const int EVIA_V35[7] = {760, -1, 36, -1, 1, 1, 1};
static const int* EVIA[36] = {
     EVIA_V0, EVIA_V1, EVIA_V2, EVIA_V3, EVIA_V4, EVIA_V5, EVIA_V6, EVIA_V7, EVIA_V8, EVIA_V9
   , EVIA_V10, EVIA_V11, EVIA_V12, EVIA_V13, EVIA_V14, EVIA_V15, EVIA_V16, EVIA_V17, EVIA_V18, EVIA_V19
   , EVIA_V20, EVIA_V21, EVIA_V22, EVIA_V23, EVIA_V24, EVIA_V25, EVIA_V26, EVIA_V27, EVIA_V28, EVIA_V29
   , EVIA_V30, EVIA_V31, EVIA_V32, EVIA_V33, EVIA_V34, EVIA_V35
};

// Submodel ESSBATCP2D01V01 . 1
// variable soc (Multiline var)
static const int IVIA_V0[4] = {6, -1, 1, 1};
// variable I (Multiline var)
static const int IVIA_V1[4] = {7, -1, 1, 1};
// variable U (Multiline var)
static const int IVIA_V2[4] = {8, -1, 1, 1};
// variable Ufilt (Explicit state)
static const int IVIA_V3[4] = {-1, -1, 1, 0};
// variable Uconst (Constraint var)
static const int IVIA_V4[4] = {-1, -1, 1, 0};
// variable Uunfilt (Multiline var)
static const int IVIA_V5[4] = {9, -1, 1, 1};
// variable Uunfilt2 (Multiline var)
static const int IVIA_V6[4] = {10, -1, 1, 1};
// variable poscs (Explicit state)
static const int IVIA_V7[4] = {11, 0, 10, 10};
// variable negcs (Explicit state)
static const int IVIA_V8[4] = {111, 100, 10, 10};
// variable eleCs (Explicit state)
static const int IVIA_V9[4] = {211, 200, 30, 1};
// variable posUeq (Multiline shared var)
static const int IVIA_V10[4] = {241, -1, 10, 1};
// variable negUeq (Multiline shared var)
static const int IVIA_V11[4] = {251, -1, 10, 1};
// variable eleUeq (Multiline shared var)
static const int IVIA_V12[4] = {261, -1, 30, 1};
// variable posUeqmean (Basic var)
static const int IVIA_V13[4] = {291, -1, 1, 1};
// variable negUeqmean (Basic var)
static const int IVIA_V14[4] = {292, -1, 1, 1};
// variable posUeqav (Basic var)
static const int IVIA_V15[4] = {293, -1, 1, 1};
// variable negUeqav (Basic var)
static const int IVIA_V16[4] = {294, -1, 1, 1};
// variable posx100 (Multiline shared var)
static const int IVIA_V17[4] = {295, -1, 1, 1};
// variable negx100 (Multiline shared var)
static const int IVIA_V18[4] = {296, -1, 1, 1};
// variable posx (Multiline shared var)
static const int IVIA_V19[4] = {297, -1, 10, 1};
// variable negx (Multiline shared var)
static const int IVIA_V20[4] = {307, -1, 10, 1};
// variable posxmean (Multiline shared var)
static const int IVIA_V21[4] = {317, -1, 1, 1};
// variable negxmean (Multiline shared var)
static const int IVIA_V22[4] = {318, -1, 1, 1};
// variable dUdT (Basic var)
static const int IVIA_V23[4] = {319, -1, 1, 1};
// variable ocv (Basic var)
static const int IVIA_V24[4] = {320, -1, 1, 1};
// variable ocvav (Basic var)
static const int IVIA_V25[4] = {321, -1, 1, 1};
// variable hystfact (Explicit state)
static const int IVIA_V26[4] = {322, 230, 1, 1};
// variable posDsc (Basic var)
static const int IVIA_V27[4] = {323, -1, 10, 10};
// variable negDsc (Basic var)
static const int IVIA_V28[4] = {423, -1, 10, 10};
// variable eleDeff (Basic var)
static const int IVIA_V29[4] = {523, -1, 30, 1};
// variable elekapac (Multiline shared var)
static const int IVIA_V30[4] = {553, -1, 30, 1};
// variable eletplus (Multiline shared var)
static const int IVIA_V31[4] = {583, -1, 30, 1};
// variable jf (Multiline shared var)
static const int IVIA_V32[4] = {613, -1, 30, 1};
// variable sloss (Basic var)
static const int IVIA_V33[4] = {643, -1, 1, 1};
// variable hloss (Basic var)
static const int IVIA_V34[4] = {644, -1, 1, 1};
// variable phie (Multiline shared var)
static const int IVIA_V35[4] = {645, -1, 30, 1};
// variable negetak (Multiline shared var)
static const int IVIA_V36[4] = {675, -1, 10, 1};
// variable negsigmaEff (Multiline shared var)
static const int IVIA_V37[4] = {685, -1, 1, 1};
// variable possigmaEff (Multiline shared var)
static const int IVIA_V38[4] = {686, -1, 1, 1};
// variable posetak (Multiline shared var)
static const int IVIA_V39[4] = {687, -1, 10, 1};
// variable negdeltaphi (Multiline shared var)
static const int IVIA_V40[4] = {697, -1, 10, 1};
// variable posdeltaphi (Multiline shared var)
static const int IVIA_V41[4] = {707, -1, 10, 1};
// variable dnegdeltaphi (Multiline shared var)
static const int IVIA_V42[4] = {717, -1, 10, 1};
// variable dposdeltaphi (Multiline shared var)
static const int IVIA_V43[4] = {727, -1, 10, 1};
// variable negdeltaphiDLcap (Explicit state)
static const int IVIA_V44[4] = {-1, -1, 0, 1};
// variable posdeltaphiDLcap (Explicit state)
static const int IVIA_V45[4] = {-1, -1, 0, 1};
// variable negdeltaphiConst (Constraint var)
static const int IVIA_V46[4] = {-1, -1, 0, 1};
// variable posdeltaphiConst (Constraint var)
static const int IVIA_V47[4] = {-1, -1, 0, 1};
// variable posmeandeltaphi (Multiline shared var)
static const int IVIA_V48[4] = {737, -1, 1, 1};
// variable negmeandeltaphi (Multiline shared var)
static const int IVIA_V49[4] = {738, -1, 1, 1};
// variable posmeanUeq (Multiline shared var)
static const int IVIA_V50[4] = {739, -1, 1, 1};
// variable negmeanUeq (Multiline shared var)
static const int IVIA_V51[4] = {740, -1, 1, 1};
// variable posmeanetaohm (Multiline shared var)
static const int IVIA_V52[4] = {741, -1, 1, 1};
// variable negmeanetaohm (Multiline shared var)
static const int IVIA_V53[4] = {742, -1, 1, 1};
// variable posmeanetakin (Multiline shared var)
static const int IVIA_V54[4] = {743, -1, 1, 1};
// variable negmeanetakin (Multiline shared var)
static const int IVIA_V55[4] = {744, -1, 1, 1};
// variable elemeanetaohm (Multiline shared var)
static const int IVIA_V56[4] = {745, -1, 1, 1};
// variable elemeanetadiff (Multiline shared var)
static const int IVIA_V57[4] = {746, -1, 1, 1};
// variable poskT (Multiline shared var)
static const int IVIA_V58[4] = {747, -1, 1, 1};
// variable negkT (Multiline shared var)
static const int IVIA_V59[4] = {748, -1, 1, 1};
// Submodel CONS00 . 1
// variable k0GEN (Discrete var)
static const int IVIA_V60[4] = {765, -1, 1, 1};
// Submodel THCS1 . 1
// Submodel THTS1 . 1
// Submodel EBAS03 . 1
// variable U (Basic var)
static const int IVIA_V61[4] = {754, -1, 1, 1};
// variable I (Basic var)
static const int IVIA_V62[4] = {755, -1, 1, 1};
// Submodel EB3N03 . 1
// Submodel EB3N05 . 1
// variable Ileak (Basic var)
static const int IVIA_V63[4] = {763, -1, 1, 1};
// variable powerCelec (Activity var)
static const int IVIA_V64[4] = {764, -1, 1, 1};
// variable energyCelec (Explicit state)
static const int IVIA_V65[4] = {-1, -1, 1, 0};
// variable actCelec (Explicit state)
static const int IVIA_V66[4] = {-1, -1, 1, 0};
// Submodel EBVT01 . 1
// variable U (Basic var)
static const int IVIA_V67[4] = {761, -1, 1, 1};
// variable I (Fixed var)
static const int IVIA_V68[4] = {762, -1, 1, 1};
// Submodel SSINK . 1
// Submodel STOP0 . 1
// variable xref (Discrete var)
static const int IVIA_V69[4] = {768, -1, 1, 1};
static const int* IVIA[70] = {
     IVIA_V0, IVIA_V1, IVIA_V2, IVIA_V3, IVIA_V4, IVIA_V5, IVIA_V6, IVIA_V7, IVIA_V8, IVIA_V9
   , IVIA_V10, IVIA_V11, IVIA_V12, IVIA_V13, IVIA_V14, IVIA_V15, IVIA_V16, IVIA_V17, IVIA_V18, IVIA_V19
   , IVIA_V20, IVIA_V21, IVIA_V22, IVIA_V23, IVIA_V24, IVIA_V25, IVIA_V26, IVIA_V27, IVIA_V28, IVIA_V29
   , IVIA_V30, IVIA_V31, IVIA_V32, IVIA_V33, IVIA_V34, IVIA_V35, IVIA_V36, IVIA_V37, IVIA_V38, IVIA_V39
   , IVIA_V40, IVIA_V41, IVIA_V42, IVIA_V43, IVIA_V44, IVIA_V45, IVIA_V46, IVIA_V47, IVIA_V48, IVIA_V49
   , IVIA_V50, IVIA_V51, IVIA_V52, IVIA_V53, IVIA_V54, IVIA_V55, IVIA_V56, IVIA_V57, IVIA_V58, IVIA_V59
   , IVIA_V60, IVIA_V61, IVIA_V62, IVIA_V63, IVIA_V64, IVIA_V65, IVIA_V66, IVIA_V67, IVIA_V68, IVIA_V69
};

static const int PVIA[37] = {
     1, 0, 3, 2, 5, 4, 753, 766, 767, 4
   , 5, 766, 750, 749, 752, 751, 753, 757, 756, 749
   , 750, 2, 3, 758, 231, 759, 0, 1, 751, 752
   , 759, 758, 760, 756, 757, 767, 760
};

// Submodel ESSBATCP2D01V01 . 1
static const int RPARAM_0[2] = {0, 1};
static const int RPARAM_1[2] = {1, 1};
static const int RPARAM_2[2] = {2, 1};
static const int RPARAM_3[2] = {3, 1};
static const int RPARAM_4[2] = {4, 1};
static const int RPARAM_5[2] = {5, 1};
static const int RPARAM_6[2] = {6, 1};
static const int RPARAM_7[2] = {7, 1};
static const int RPARAM_8[2] = {8, 1};
static const int RPARAM_9[2] = {9, 1};
static const int RPARAM_10[2] = {10, 1};
static const int RPARAM_11[2] = {11, 1};
static const int RPARAM_12[2] = {12, 1};
static const int RPARAM_13[2] = {13, 1};
static const int RPARAM_14[2] = {14, 1};
static const int RPARAM_15[2] = {15, 1};
static const int RPARAM_16[2] = {16, 1};
static const int RPARAM_17[2] = {17, 1};
static const int RPARAM_18[2] = {18, 1};
static const int RPARAM_19[2] = {19, 1};
static const int RPARAM_20[2] = {20, 1};
static const int RPARAM_21[2] = {21, 1};
static const int RPARAM_22[2] = {22, 1};
static const int RPARAM_23[2] = {23, 1};
static const int RPARAM_24[2] = {24, 1};
static const int RPARAM_25[2] = {25, 1};
static const int RPARAM_26[2] = {26, 1};
static const int RPARAM_27[2] = {27, 1};
static const int RPARAM_28[2] = {28, 1};
static const int RPARAM_29[2] = {29, 1};
static const int RPARAM_30[2] = {30, 1};
static const int RPARAM_31[2] = {31, 1};
static const int RPARAM_32[2] = {32, 1};
static const int RPARAM_33[2] = {33, 1};
static const int IPARAM_34[2] = {0, 1};
static const int IPARAM_35[2] = {1, 1};
static const int IPARAM_36[2] = {2, 1};
static const int IPARAM_37[2] = {3, 1};
static const int IPARAM_38[2] = {4, 1};
static const int IPARAM_39[2] = {5, 1};
static const int IPARAM_40[2] = {6, 1};
static const int IPARAM_41[2] = {7, 1};
static const int IPARAM_42[2] = {8, 1};
static const int IPARAM_43[2] = {9, 1};
static const int IPARAM_44[2] = {10, 1};
static const int IPARAM_45[2] = {11, 1};
static const int IPARAM_46[2] = {12, 1};
static const int IPARAM_47[2] = {13, 1};
static const int TPARAM_48[2] = {0, 1};
static const int TPARAM_49[2] = {1, 1};
static const int TPARAM_50[2] = {2, 1};
static const int TPARAM_51[2] = {3, 1};
static const int TPARAM_52[2] = {4, 1};
static const int TPARAM_53[2] = {5, 1};
static const int TPARAM_54[2] = {6, 1};
static const int TPARAM_55[2] = {7, 1};
static const int TPARAM_56[2] = {8, 1};
static const int TPARAM_57[2] = {9, 1};
static const int TPARAM_58[2] = {10, 1};
static const int TPARAM_59[2] = {11, 1};
static const int TPARAM_60[2] = {12, 1};
static const int TPARAM_61[2] = {13, 1};
static const int TPARAM_62[2] = {14, 1};
// Submodel CONS00 . 1
static const int RPARAM_63[2] = {0, 1};
// Submodel THCS1 . 1
// Submodel THTS1 . 1
// Submodel EBAS03 . 1
// Submodel EB3N03 . 1
// Submodel EB3N05 . 1
static const int RPARAM_64[2] = {0, 1};
// Submodel EBVT01 . 1
static const int RPARAM_65[2] = {0, 1};
static const int RPARAM_66[2] = {1, 1};
static const int IPARAM_67[2] = {0, 1};
// Submodel SSINK . 1
// Submodel STOP0 . 1
static const int IPARAM_68[2] = {0, 1};
static const int IPARAM_69[2] = {1, 1};
static const int IPARAM_70[2] = {2, 1};
static const int IPARAM_71[2] = {3, 1};
static const int TPARAM_72[2] = {0, 1};
static const int TPARAM_73[2] = {1, 1};
static const int* PIA[74] = {
     RPARAM_0, RPARAM_1, RPARAM_2, RPARAM_3, RPARAM_4, RPARAM_5, RPARAM_6, RPARAM_7, RPARAM_8, RPARAM_9
   , RPARAM_10, RPARAM_11, RPARAM_12, RPARAM_13, RPARAM_14, RPARAM_15, RPARAM_16, RPARAM_17, RPARAM_18, RPARAM_19
   , RPARAM_20, RPARAM_21, RPARAM_22, RPARAM_23, RPARAM_24, RPARAM_25, RPARAM_26, RPARAM_27, RPARAM_28, RPARAM_29
   , RPARAM_30, RPARAM_31, RPARAM_32, RPARAM_33, IPARAM_34, IPARAM_35, IPARAM_36, IPARAM_37, IPARAM_38, IPARAM_39
   , IPARAM_40, IPARAM_41, IPARAM_42, IPARAM_43, IPARAM_44, IPARAM_45, IPARAM_46, IPARAM_47, TPARAM_48, TPARAM_49
   , TPARAM_50, TPARAM_51, TPARAM_52, TPARAM_53, TPARAM_54, TPARAM_55, TPARAM_56, TPARAM_57, TPARAM_58, TPARAM_59
   , TPARAM_60, TPARAM_61, TPARAM_62, RPARAM_63, RPARAM_64, RPARAM_65, RPARAM_66, IPARAM_67, IPARAM_68, IPARAM_69
   , IPARAM_70, IPARAM_71, TPARAM_72, TPARAM_73
};


static const int** NGIA = NULL;

static const int* NIA = NULL;

static const int SUBSIMU[10][6][2] = {
     {{34, 0}, {14, 0}, {15, 0}, {0, 0}, {0, 0}, {1, 0}}
   , {{1, 37}, {0, 15}, {0, 15}, {0, 0}, {0, 1}, {0, 1}}
   , {{0, 38}, {0, 15}, {0, 15}, {0, 0}, {0, 1}, {0, 1}}
   , {{0, 38}, {0, 15}, {0, 15}, {0, 0}, {0, 1}, {0, 1}}
   , {{0, 34}, {0, 14}, {0, 15}, {0, 0}, {0, 0}, {0, 1}}
   , {{0, 34}, {0, 14}, {0, 15}, {0, 0}, {0, 0}, {0, 1}}
   , {{1, 36}, {0, 15}, {0, 15}, {0, 0}, {1, 0}, {0, 1}}
   , {{2, 34}, {1, 14}, {0, 15}, {0, 0}, {0, 0}, {0, 1}}
   , {{0, 38}, {0, 15}, {0, 15}, {0, 0}, {0, 1}, {0, 1}}
   , {{0, 38}, {4, 15}, {2, 15}, {2, 0}, {3, 1}, {0, 1}}
};

static const S_AMESubStructuralInfo STLI_0 = {1, &EVIA[0], &IVIA[0], PVIA, &PIA[0], NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_1 = {1, &EVIA[6], &IVIA[60], PVIA, &PIA[63], NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_2 = {1, &EVIA[7], NULL, PVIA, NULL, NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_3 = {1, &EVIA[11], NULL, PVIA, NULL, NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_4 = {1, &EVIA[12], &IVIA[61], PVIA, NULL, NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_5 = {1, &EVIA[17], NULL, PVIA, NULL, NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_6 = {1, &EVIA[23], &IVIA[63], PVIA, &PIA[64], NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_7 = {1, &EVIA[29], &IVIA[67], PVIA, &PIA[65], NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_8 = {1, &EVIA[34], NULL, PVIA, NULL, NULL, NULL, NULL};
static const S_AMESubStructuralInfo STLI_9 = {1, &EVIA[35], &IVIA[69], PVIA, &PIA[68], NULL, NULL, NULL};

/* *******************  Function prototypes ************ */

extern AMEModelStatus cons00_in(const S_AMESubIntf *sitf);
extern AMEModelStatus cons00_calc(const S_AMESubIntf *sitf);
extern AMEModelStatus cons00_end(const S_AMESubIntf *sitf);
extern AMEModelStatus thts1_in(const S_AMESubIntf *sitf);
extern AMEModelStatus thts1_end(const S_AMESubIntf *sitf);
extern void eb3n05in_(int *n, double *RP, int *IS, double *y0
                   , double *y1, double *y2);
extern void eb3n05_(int *n, double *ve0, double *vedot0, double *ve1
                   , double *ve2, double *ve3, double *vi4, double *vi5
                   , double *vi6, double *vidot6, double *vi7
                   , double *vidot7, double *RP, int *IS);
extern void essbatcp2d01v01in_(int *n, double *RP, int *IP, char **TP
                 , void **PS, double *y0, double *y1, double *y2
                   , double *y3, double *y4, double *y5, double *y6
                   , double *y7, double *y8, double *y9);
extern void essbatcp2d01v01_(int *n, double *port_1_v2, double *port_2_v2
                   , double *port_3_v1, double *port_3_v2, double *int_v1
                   , double *int_v2, double *int_v3, double *int_v4
                   , double *int_dv4, double *int_v5, double *int_rv5
                   , double *int_v6, double *int_v7, double *int_v8
                   , double *int_dv8, double *int_v9, double *int_dv9
                   , double *int_v10, double *int_dv10, double *int_v11
                   , double *int_v12, double *int_v13, double *int_v14
                   , double *int_v15, double *int_v16, double *int_v17
                   , double *int_v18, double *int_v19, double *int_v20
                   , double *int_v21, double *int_v22, double *int_v23
                   , double *int_v24, double *int_v25, double *int_v26
                   , double *int_v27, double *int_dv27, double *int_v28
                   , double *int_v29, double *int_v30, double *int_v31
                   , double *int_v32, double *int_v33, double *int_v34
                   , double *int_v35, double *int_v36, double *int_v37
                   , double *int_v38, double *int_v39, double *int_v40
                   , double *int_v41, double *int_v42, double *int_v43
                   , double *int_v44, double *int_v45, double *int_dv45
                   , double *int_v46, double *int_dv46, double *int_v47
                   , double *int_rv47, double *int_v48, double *int_rv48
                   , double *int_v49, double *int_v50, double *int_v51
                   , double *int_v52, double *int_v53, double *int_v54
                   , double *int_v55, double *int_v56, double *int_v57
                   , double *int_v58, double *int_v59, double *int_v60
                   , double *RP, int *IP, char **TP, void **PS
                 , int *flag, double *t);
extern void essbatcp2d01v01end_(int *n, double *RP, int *IP, char **TP
                 , void **PS, double *y0, double *y1, double *y2
                   , double *y3, double *y4, double *y5, double *y6
                   , double *y7, double *y8, double *y9);
extern double essbatcp2d01v01_soc_(int *n, double *m0, double *m1
              , double *m2, double *m3, double *m4, double *m5
              , double *RP, int *IP, char **TP, void **PS, int *flag
                   , double *t, int *macindex);
extern double essbatcp2d01v01_I_(int *n, double *m0, double *RP
                 , int *IP, char **TP, void **PS, int *flag, double *t
                   , int *macindex);
extern double essbatcp2d01v01_U_(int *n, double *m0, double *m1
              , double *m2, double *RP, int *IP, char **TP, void **PS
                 , int *flag, double *t, int *macindex);
extern double essbatcp2d01v01_Uunfilt_(int *n, double *m0, double *m1
              , double *m2, double *m3, double *m4, double *m5
              , double *m6, double *m7, double *m8, double *m9
              , double *m10, double *m11, double *m12, double *m13
              , double *m14, double *m15, double *m16, double *m17
              , double *m18, double *m19, double *m20, double *m21
              , double *m22, double *m23, double *m24, double *m25
              , double *m26, double *m27, double *m28, double *m29
              , double *m30, double *m31, double *m32, double *m33
              , double *m34, double *m35, double *m36, double *m37
              , double *m38, double *m39, double *RP, int *IP
                 , char **TP, void **PS, int *flag, double *t
                   , int *macindex);
extern double essbatcp2d01v01_Uunfilt2_(int *n, int *var_group_index
              , double *m0, double *RP, int *IP, char **TP, void **PS
                 , int *flag, double *t, int *macindex);
extern void eb3n03in_(int *n);
extern void ebvt01in_(int *n, double *RP, int *IP, double *y0
                   , double *y1, double *y2);
extern void ebvt01_(int *n, double *ve0, double *ve1, double *ve2
                   , double *vi3, double *RP, int *IP);
extern AMEModelStatus thcs1_in(const S_AMESubIntf *sitf);
extern AMEModelStatus thcs1_end(const S_AMESubIntf *sitf);
extern AMEModelStatus ssink_in(const S_AMESubIntf *sitf);
extern AMEModelStatus ssink_end(const S_AMESubIntf *sitf);
extern AMEModelStatus stop0_in(const S_AMESubIntf *sitf);
extern AMEModelStatus stop0_calc(const S_AMESubIntf *sitf);
extern AMEModelStatus stop0_end(const S_AMESubIntf *sitf);
extern void ebas03in_(int *n);
extern void ebas03_(int *n, double *ve0, double *ve1, double *ve2
                   , double *vi3, double *vi4);

/* ******************    Here comes the functions ************ */
static void PreInitialize(AMESIMSYSTEM *amesys, double *y)
{
   int n = 0;
   double *v = amesys->v;
   double *Z = amesys->discrete_states;
   double *dbk_wk = amesys->pModel->dbk_wk;
   const double t = getstarttime_();
   S_AMESubIntf sitf = {amesys, NULL, NULL, t, NULL, v, NULL};
   AMEModelStatus status = AME_MODEL_OK;


   (void)n;

   /* Assign continuous state variables calculated by the integrator */
#if( (AME_MODEL_ISEXPLICIT == 0) && (AME_NBOF_SOLVER_STATES > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_SOLVER_STATES; idxState++) {
         v[GcontStateVarNum[idxState]] = y[idxState];
      }
   }
#elif( (AME_MODEL_ISEXPLICIT == 1) && (AME_NBOF_EXPLICIT_STATE > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_EXPLICIT_STATE; idxState++) {
         v[GcontStateVarNum[idxState]] = y[idxState];
      }
   }
#endif

   /* Assign discrete state variables */
#if( AME_NBOF_DISCRETE_STATE > 0 )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_DISCRETE_STATE; idxState++) {
         v[GdiscStateVarNum[idxState]] = Z[idxState];
      }
   }
#endif

   InitializeUnitsManagerAsDefault();


   /* Assign continuous state variables initialized by submodels */
#if( (AME_MODEL_ISEXPLICIT == 0) && (AME_NBOF_SOLVER_STATES > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_SOLVER_STATES; idxState++) {
         y[idxState] = v[GcontStateVarNum[idxState]];
      }
   }
#elif( (AME_MODEL_ISEXPLICIT == 1) && (AME_NBOF_EXPLICIT_STATE > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_EXPLICIT_STATE; idxState++) {
         y[idxState] = v[GcontStateVarNum[idxState]];
      }
   }
#endif

   /* Assign discrete state initialized by submodels */
#if( AME_NBOF_DISCRETE_STATE > 0 )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_DISCRETE_STATE; idxState++) {
         Z[idxState] = v[GdiscStateVarNum[idxState]];
      }
   }
#endif

   if(status & AME_MODEL_FATAL) AmeExit(1);
}

static void Initialize(AMESIMSYSTEM *amesys, double *y)
{
   int n;
   double *v = amesys->v;
   double *Z = amesys->discrete_states;
   double *dbk_wk = amesys->pModel->dbk_wk;
   const double t = getstarttime_();
   S_AMESubIntf sitf = {amesys, NULL, NULL, t, NULL, v, NULL};
   AMEModelStatus status = AME_MODEL_OK;


   (void)n;

   /* Assign continuous state variables */
#if( (AME_MODEL_ISEXPLICIT == 0) && (AME_NBOF_SOLVER_STATES > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_SOLVER_STATES; idxState++) {
         v[GcontStateVarNum[idxState]] = y[idxState];
      }
   }
#elif( (AME_MODEL_ISEXPLICIT == 1) && (AME_NBOF_EXPLICIT_STATE > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_EXPLICIT_STATE; idxState++) {
         v[GcontStateVarNum[idxState]] = y[idxState];
      }
   }
#endif

   /* Assign discrete state variables */
#if( AME_NBOF_DISCRETE_STATE > 0 )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_DISCRETE_STATE; idxState++) {
         v[GdiscStateVarNum[idxState]] = Z[idxState];
      }
   }
#endif

   sitf.structuralInfo = &STLI_1;
   sitf.simulationInfo = &amesys->pModel->subArray[1];
   status |= cons00_in(&sitf);
   if(status & AME_MODEL_FATAL) goto _amefunc_init_end;
   sitf.structuralInfo = &STLI_3;
   sitf.simulationInfo = &amesys->pModel->subArray[3];
   status |= thts1_in(&sitf);
   if(status & AME_MODEL_FATAL) goto _amefunc_init_end;

   n = 1;
   eb3n05in_(&n, RP4, IS4, &v[758], NULL, NULL);

   n = 1;
   {


      essbatcp2d01v01in_(&n, RP0, IP0, TP0, PS0, NULL, NULL, &v[11]
         , &v[111], &v[211], &v[322], NULL, NULL, NULL, NULL);
   }

   n = 1;
   eb3n03in_(&n);

   n = 1;
   ebvt01in_(&n, RP3, IP3, &v[759], &v[756], &v[762]);
   sitf.structuralInfo = &STLI_2;
   sitf.simulationInfo = &amesys->pModel->subArray[2];
   status |= thcs1_in(&sitf);
   if(status & AME_MODEL_FATAL) goto _amefunc_init_end;
   sitf.structuralInfo = &STLI_8;
   sitf.simulationInfo = &amesys->pModel->subArray[8];
   status |= ssink_in(&sitf);
   if(status & AME_MODEL_FATAL) goto _amefunc_init_end;
   sitf.structuralInfo = &STLI_9;
   sitf.simulationInfo = &amesys->pModel->subArray[9];
   status |= stop0_in(&sitf);
   if(status & AME_MODEL_FATAL) goto _amefunc_init_end;

   n = 1;
   ebas03in_(&n);

   /* Assign continuous state variables initialized by submodels */
#if( (AME_MODEL_ISEXPLICIT == 0) && (AME_NBOF_SOLVER_STATES > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_SOLVER_STATES; idxState++) {
         y[idxState] = v[GcontStateVarNum[idxState]];
      }
   }
#elif( (AME_MODEL_ISEXPLICIT == 1) && (AME_NBOF_EXPLICIT_STATE > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_EXPLICIT_STATE; idxState++) {
         y[idxState] = v[GcontStateVarNum[idxState]];
      }
   }
#endif

   /* Assign discrete state initialized by submodels */
#if( AME_NBOF_DISCRETE_STATE > 0 )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_DISCRETE_STATE; idxState++) {
         Z[idxState] = v[GdiscStateVarNum[idxState]];
      }
   }
#endif

_amefunc_init_end:
   if(status & AME_MODEL_FATAL) AmeExit(1);
}

#define AME_HAS_ENABLED_SUBMODEL    0

static void localFuncEval(AMESIMSYSTEM *amesys, double t, double *y, double *yprime, double *delta, int *flag)
{
   int sflag, oflag, n, panic, i=0;
   int *oldflag, *newflag;
   double *v = amesys->v;
   double *Z = amesys->discrete_states;
   double *input = amesys->inputs;
   double *output = amesys->outputs;
   double *dbk_wk = amesys->pModel->dbk_wk;
   AMEModelStatus status = AME_MODEL_OK;

#if(AME_MODEL_ISEXPLICIT == 1)
   double *dot = yprime;
   S_AMESubIntf sitf = {amesys, NULL, NULL, t, &sflag, v, dot};

#if(AME_HAS_ENABLED_SUBMODEL == 1)
   memset(dot,0,AME_NBOF_SOLVER_STATES*sizeof(double));
#elif (AME_NBOF_EXPLICIT_STATE == 0)
   dot[0] = 0.0;
#endif

#else
   double dot[AME_NBOF_SOLVER_STATES];
   S_AMESubIntf sitf = {amesys, NULL, NULL, t, &sflag, v, dot};

   /* Initialize the dot vector to the yprime vector. */
   memcpy((void *)dot, (void *)yprime, AME_NBOF_SOLVER_STATES*sizeof(double));
#endif

   SetGlobalSystem(amesys);

   (void)n;

#if(defined(AME_COSIM) && (AME_NBOF_INPUTS > 0))
   if(amesys->doInterpol) {
      if( getInputsCosimSlave(amesys->csSlave, t, input) != AME_NO_ERROR ) {
         AmeExit(1);
      }
   }
#endif

   /* Record old value of flag (oflag) and set
      flag value for use in submodels (sflag).
      Also get addresses of main discontinuity flags. */

   oflag = *flag;
   sflag = *flag;

   if(amesys->first_call)
   {
      GetFlagAddresses(&amesys->oldflag, &amesys->newflag);
   }
   oldflag = amesys->oldflag;
   newflag = amesys->newflag;

   /* Initialize everything ready for potential calls to stepdn
      in submodels. */

   panic = 0;
   getredstep();

   if(isstabrun_())
   {
      t = amesys->simOptions->fixedTime;
      sitf.t = t;
   }
   else if(*flag == 2)
   {
      /* Record current simulation time for message passing. */

      SetSimTime(t);
   }
   /* Record current simulation time for ametim_(). */

   SetTimeAtThisStep(t);

   if (holdinputs_())
   {
      /* We reset artificially the time to the initial value
         to give the illusion of held inputs. */
      t = getstarttime_();
      sitf.t = t;
   }
   /* Assign the state variables y[] calculated by the integrator
      to the appropriate variables v[]. */

   /* Assign continuous state variables calculated by the integrator */
#if( (AME_MODEL_ISEXPLICIT == 0) && (AME_NBOF_SOLVER_STATES > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_SOLVER_STATES; idxState++) {
         v[GcontStateVarNum[idxState]] = y[idxState];
      }
   }
#elif( (AME_MODEL_ISEXPLICIT == 1) && (AME_NBOF_EXPLICIT_STATE > 0) )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_EXPLICIT_STATE; idxState++) {
         v[GcontStateVarNum[idxState]] = y[idxState];
      }
   }
#endif

   /* Assign discrete state variables */
#if( AME_NBOF_DISCRETE_STATE > 0 )
   {
      int idxState;
      for(idxState = 0; idxState < AME_NBOF_DISCRETE_STATE; idxState++) {
         v[GdiscStateVarNum[idxState]] = Z[idxState];
      }
   }
#endif

   /* Assign the interface input variables to the appropriate variable v(). */
#if(AME_NBOF_INPUTS > 0)
   {
      int idxInput;
      for(idxInput = 0; idxInput < AME_NBOF_INPUTS; idxInput++) {
         v[GInputVarNum[idxInput]] = input[idxInput];
      }
   }
#endif

#if(AME_MODEL_ISEXPLICIT == 1)
  /* The following call ensures that lsoda does not integrate past
      time amesys->t_end_of_time_slice. This does not matter in a standard AMESim run but is
      very important with cosimulation. */

#ifdef AME_COSIM
   *oldflag = *newflag = sflag;
   discInput(&amesys->t_end_of_time_slice);
   AME_POST_SUBMODCALL_WITH_DISCON(amesys, flag,&sflag,&oflag,&panic,"_TunableParam",1);
#endif

#else
   if(*flag == 5)
   {
      DPerturbIfNecessary(amesys, flag);
   }

#ifdef AME_COSIM
   *oldflag = *newflag = sflag;
   discInput(&amesys->t_end_of_time_slice);
   AME_POST_SUBMODCALL_WITH_DISCON(amesys, flag,&sflag,&oflag,&panic,"_TunableParam",1);
#endif

#endif

   /* Call submodel calculation subroutine in the order
      that ensures the input requirements of each submodel
      are satisfied. */

#if (NB_REAL_TUNABLE_PARAM > 0) || (NB_INT_TUNABLE_PARAM > 0)
   if(*flag == 0)
   {
      int idxParam;
#if (NB_REAL_TUNABLE_PARAM > 0)
      for(idxParam = 0; idxParam < NB_REAL_TUNABLE_PARAM; idxParam++) {
         v[GRealTunableParam[idxParam][1]] = amesys->pModel->realParamArray[GRealTunableParam[idxParam][0]];
      }
#endif
#if(NB_INT_TUNABLE_PARAM > 0)
      for(idxParam = 0; idxParam < NB_INT_TUNABLE_PARAM; idxParam++) {
         v[GIntTunableParam[idxParam][1]] = amesys->pModel->integerParamArray[GIntTunableParam[idxParam][0]];
      }
#endif
   }
#endif


   n = 1;
   *oldflag = *newflag = sflag;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"ESSBATCP2D01V01",1);

   {
      *oldflag = *newflag = sflag;
      sitf.structuralInfo = &STLI_1;
      sitf.simulationInfo = &amesys->pModel->subArray[1];
      status |= cons00_calc(&sitf);
      AME_POST_SUBMODCALL_WITH_DISCON(amesys, flag, &sflag, &oflag, &panic, "CONS00", 1);
   }
   {
      v[4] = v[766];
      AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);
   }
   v[750] = -v[753] /* Duplicate variable. */;
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   v[752] = v[753] /* Duplicate variable. */;
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   v[2] = v[756]+v[750];
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   v[1] = v[2] /* Duplicate variable. */;
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   n = 1;
   *oldflag = *newflag = sflag;
   {  /* DBK macro start. */
      int izero = 0;
      v[7] = essbatcp2d01v01_I_(&n, &v[2], RP0, IP0, TP0, PS0
         , &sflag, &t, &izero);
   }  /* DBK macro end. */
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"ESSBATCP2D01V01",1);

   n = 1;
   *oldflag = *newflag = sflag;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"ESSBATCP2D01V01",1);

   n = 1;
   *oldflag = *newflag = sflag;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"ESSBATCP2D01V01",1);

   n = 1;
   *oldflag = *newflag = sflag;
   eb3n05_(&n, &v[758], &dot[231], &v[759], &v[1], &v[752], &v[763]
      , &v[764], NULL, NULL, NULL, NULL, RP4, IS4);
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"EB3N05",1);

   v[0] = v[758] /* Duplicate variable. */;
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   v[751] = v[758] /* Duplicate variable. */;
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   n = 1;
   *oldflag = *newflag = sflag;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"ESSBATCP2D01V01",1);

   n = 1;
   *oldflag = *newflag = sflag;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"ESSBATCP2D01V01",1);

   v[3] = v[0]+v[8];
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   v[757] = v[3] /* Duplicate variable. */;
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   v[749] = v[3] /* Duplicate variable. */;
   AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);

   n = 1;
   *oldflag = *newflag = sflag;
   ebvt01_(&n, &v[758], &v[760], &v[757], &v[761], RP3, IP3);
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"EBVT01",1);

   {
      v[767] = v[5];
      AME_POST_SUBMODCALL_NO_DISCON(amesys,flag);
   }
   {
      *oldflag = *newflag = sflag;
      sitf.structuralInfo = &STLI_9;
      sitf.simulationInfo = &amesys->pModel->subArray[9];
      status |= stop0_calc(&sitf);
      AME_POST_SUBMODCALL_WITH_DISCON(amesys, flag, &sflag, &oflag, &panic, "STOP0", 1);
   }
   n = 1;
   *oldflag = *newflag = sflag;
   ebas03_(&n, &v[749], &v[751], &v[753], &v[754], &v[755]);
   AME_POST_SUBMODCALL_WITH_DISCON(amesys,flag,&sflag,&oflag,&panic,"EBAS03",1);



   /* Set interface outputs here. */
#if(AME_NBOF_OUTPUTS > 0)
   {
      int idxOutput;
      for(idxOutput = 0; idxOutput < AME_NBOF_OUTPUTS; idxOutput++) {
         output[idxOutput] = v[GOutputVarNum[idxOutput]];
      }
   }
#endif

#if(AME_MODEL_ISEXPLICIT == 1)
   applyStateStatus(dot,AME_NBOF_SOLVER_STATES);
#else
#if( AME_NBOF_EXPLICIT_STATE > 0)
   applyStateStatus(dot,AME_NBOF_EXPLICIT_STATE);

   for(i=0;i<AME_NBOF_EXPLICIT_STATE;i++)
   {
      delta[i] = dot[i] - yprime[i];
   }
#endif
   for(i=AME_NBOF_EXPLICIT_STATE;i<(AME_NBOF_EXPLICIT_STATE + AME_NBOF_IMPLICIT_STATE_DECLARED);i++)
   {
      delta[i] = dot[i];
   }
#endif

   if(*flag == 0)
   {
      /* It is an initialization call and the user
         is permitted to change the state variables
         and discrete variables. */
      updateStatesFromModel(amesys, y, AME_CONTINUOUS_STATE|AME_DISCRETE_STATE);
   }

#if( AME_NBOF_DISCRETE_STATE > 0)
   if(is_sample_time()) {
      /* Change discrete variables */
      updateStatesFromModel(amesys, y, AME_DISCRETE_STATE);
   }
#endif

   UpFECount(amesys);

   amesys->first_call = 0;
   
   if(status & AME_MODEL_FATAL) {
      AmeExit(1);
   }
}

static AMEModelStatus localJFuncEval_0(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[11+col-0] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_10(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[21+col-10] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_20(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[31+col-20] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_30(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[41+col-30] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_40(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[51+col-40] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_50(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[61+col-50] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_60(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[71+col-60] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_70(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[81+col-70] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_80(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[91+col-80] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_90(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[101+col-90] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_100(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[111+col-100] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_110(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[121+col-110] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_120(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[131+col-120] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_130(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[141+col-130] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_140(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[151+col-140] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_150(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[161+col-150] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_160(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[171+col-160] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_170(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[181+col-170] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_180(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[191+col-180] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_190(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[201+col-190] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[6] = essbatcp2d01v01_soc_(&n, &v[11], &v[111], &v[295], &v[296], &v[317], &v[318]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_200(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[211+col-200] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_230(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[322] = y[col];
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[9] = essbatcp2d01v01_Uunfilt_(&n, &v[4], &v[6], &v[7], &v[11], &v[111], &v[211], &v[241], &v[251], &v[261], &v[297], &v[307], &v[322], &v[553], &v[583], &v[613], &v[645], &v[675], &v[685], &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL, NULL, NULL, NULL, &v[737], &v[738], &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745], &v[746], &v[747], &v[748]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      int var_group_index  = 0;
      v[10] = essbatcp2d01v01_Uunfilt2_(&n, &var_group_index, &v[9]
      , RP0, IP0, TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK macro start. */
      int izero = 0;
      v[8] = essbatcp2d01v01_U_(&n, NULL, NULL, &v[10], RP0, IP0
         , TP0, PS0, &sflag, &t, &izero);
   }  /* DBK macro end. */
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus localJFuncEval_231(AMESIMSYSTEM * amesys, double t, double * y, double * dot, double * v, double * yprime, double * delta, int col)
{
   int sflag = 1;
   int n;
   double *dbk_wk = amesys->pModel->dbk_wk;
   S_AMESubIntf sitf = { amesys, NULL, NULL, t, &sflag, v, dot };
   AMEModelStatus status = AME_MODEL_OK;

   (void)n;

   v[758] = y[col];
   n = 1;
   eb3n05_(&n, &v[758], &dot[231], &v[759], &v[1], &v[752], &v[763]
      , &v[764], NULL, NULL, NULL, NULL, RP4, IS4);
   v[0] = v[758] /* Duplicate variable. */;
   v[751] = v[758] /* Duplicate variable. */;
   n = 1;
   {  /* DBK specific start. */


      essbatcp2d01v01_(&n, &v[0], &v[2], &v[5], &v[4], &v[6], &v[7]
      , &v[8], NULL, NULL, NULL, NULL, &v[9], &v[10], &v[11], &dot[0]
      , &v[111], &dot[100], &v[211], &dot[200], &v[241], &v[251]
      , &v[261], &v[291], &v[292], &v[293], &v[294], &v[295], &v[296]
      , &v[297], &v[307], &v[317], &v[318], &v[319], &v[320], &v[321]
      , &v[322], &dot[230], &v[323], &v[423], &v[523], &v[553]
      , &v[583], &v[613], &v[643], &v[644], &v[645], &v[675], &v[685]
      , &v[686], &v[687], &v[697], &v[707], &v[717], &v[727], NULL
      , NULL, NULL, NULL, NULL, NULL, NULL, NULL, &v[737], &v[738]
      , &v[739], &v[740], &v[741], &v[742], &v[743], &v[744], &v[745]
      , &v[746], &v[747], &v[748], RP0, IP0, TP0, PS0, &sflag
      , &t);
   }
   return status;
}


static AMEModelStatus (*jfunc_table[])(AMESIMSYSTEM *, double, double *, double *, double *, double *, double *, int) = {
      localJFuncEval_0, localJFuncEval_0, localJFuncEval_0, localJFuncEval_0, localJFuncEval_0, localJFuncEval_0
      , localJFuncEval_0, localJFuncEval_0, localJFuncEval_0, localJFuncEval_0, localJFuncEval_10, localJFuncEval_10
      , localJFuncEval_10, localJFuncEval_10, localJFuncEval_10, localJFuncEval_10, localJFuncEval_10
      , localJFuncEval_10, localJFuncEval_10, localJFuncEval_10, localJFuncEval_20, localJFuncEval_20
      , localJFuncEval_20, localJFuncEval_20, localJFuncEval_20, localJFuncEval_20, localJFuncEval_20
      , localJFuncEval_20, localJFuncEval_20, localJFuncEval_20, localJFuncEval_30, localJFuncEval_30
      , localJFuncEval_30, localJFuncEval_30, localJFuncEval_30, localJFuncEval_30, localJFuncEval_30
      , localJFuncEval_30, localJFuncEval_30, localJFuncEval_30, localJFuncEval_40, localJFuncEval_40
      , localJFuncEval_40, localJFuncEval_40, localJFuncEval_40, localJFuncEval_40, localJFuncEval_40
      , localJFuncEval_40, localJFuncEval_40, localJFuncEval_40, localJFuncEval_50, localJFuncEval_50
      , localJFuncEval_50, localJFuncEval_50, localJFuncEval_50, localJFuncEval_50, localJFuncEval_50
      , localJFuncEval_50, localJFuncEval_50, localJFuncEval_50, localJFuncEval_60, localJFuncEval_60
      , localJFuncEval_60, localJFuncEval_60, localJFuncEval_60, localJFuncEval_60, localJFuncEval_60
      , localJFuncEval_60, localJFuncEval_60, localJFuncEval_60, localJFuncEval_70, localJFuncEval_70
      , localJFuncEval_70, localJFuncEval_70, localJFuncEval_70, localJFuncEval_70, localJFuncEval_70
      , localJFuncEval_70, localJFuncEval_70, localJFuncEval_70, localJFuncEval_80, localJFuncEval_80
      , localJFuncEval_80, localJFuncEval_80, localJFuncEval_80, localJFuncEval_80, localJFuncEval_80
      , localJFuncEval_80, localJFuncEval_80, localJFuncEval_80, localJFuncEval_90, localJFuncEval_90
      , localJFuncEval_90, localJFuncEval_90, localJFuncEval_90, localJFuncEval_90, localJFuncEval_90
      , localJFuncEval_90, localJFuncEval_90, localJFuncEval_90, localJFuncEval_100, localJFuncEval_100
      , localJFuncEval_100, localJFuncEval_100, localJFuncEval_100, localJFuncEval_100, localJFuncEval_100
      , localJFuncEval_100, localJFuncEval_100, localJFuncEval_100, localJFuncEval_110, localJFuncEval_110
      , localJFuncEval_110, localJFuncEval_110, localJFuncEval_110, localJFuncEval_110, localJFuncEval_110
      , localJFuncEval_110, localJFuncEval_110, localJFuncEval_110, localJFuncEval_120, localJFuncEval_120
      , localJFuncEval_120, localJFuncEval_120, localJFuncEval_120, localJFuncEval_120, localJFuncEval_120
      , localJFuncEval_120, localJFuncEval_120, localJFuncEval_120, localJFuncEval_130, localJFuncEval_130
      , localJFuncEval_130, localJFuncEval_130, localJFuncEval_130, localJFuncEval_130, localJFuncEval_130
      , localJFuncEval_130, localJFuncEval_130, localJFuncEval_130, localJFuncEval_140, localJFuncEval_140
      , localJFuncEval_140, localJFuncEval_140, localJFuncEval_140, localJFuncEval_140, localJFuncEval_140
      , localJFuncEval_140, localJFuncEval_140, localJFuncEval_140, localJFuncEval_150, localJFuncEval_150
      , localJFuncEval_150, localJFuncEval_150, localJFuncEval_150, localJFuncEval_150, localJFuncEval_150
      , localJFuncEval_150, localJFuncEval_150, localJFuncEval_150, localJFuncEval_160, localJFuncEval_160
      , localJFuncEval_160, localJFuncEval_160, localJFuncEval_160, localJFuncEval_160, localJFuncEval_160
      , localJFuncEval_160, localJFuncEval_160, localJFuncEval_160, localJFuncEval_170, localJFuncEval_170
      , localJFuncEval_170, localJFuncEval_170, localJFuncEval_170, localJFuncEval_170, localJFuncEval_170
      , localJFuncEval_170, localJFuncEval_170, localJFuncEval_170, localJFuncEval_180, localJFuncEval_180
      , localJFuncEval_180, localJFuncEval_180, localJFuncEval_180, localJFuncEval_180, localJFuncEval_180
      , localJFuncEval_180, localJFuncEval_180, localJFuncEval_180, localJFuncEval_190, localJFuncEval_190
      , localJFuncEval_190, localJFuncEval_190, localJFuncEval_190, localJFuncEval_190, localJFuncEval_190
      , localJFuncEval_190, localJFuncEval_190, localJFuncEval_190, localJFuncEval_200, localJFuncEval_200
      , localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200
      , localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200
      , localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200
      , localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200
      , localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_200
      , localJFuncEval_200, localJFuncEval_200, localJFuncEval_200, localJFuncEval_230, localJFuncEval_231
};



static void localJFuncEval(AMESIMSYSTEM *amesys, double t, double *y, double *yprime, double *delta, int col)
{
   int sflag=1; /* Only one flag value is required. */
   int n=1, i=0;
   double *v = amesys->v;
   double *vcopy = amesys->vcopy;
   double *input = amesys->inputs;
   double *output = amesys->outputs;
   double *Z = amesys->discrete_states;
   double *dbk_wk = amesys->pModel->dbk_wk;
   AMEModelStatus status = AME_MODEL_OK;
   
#if(AME_MODEL_ISEXPLICIT == 1)
   double *dot = yprime;

#else
   double dot[AME_NBOF_SOLVER_STATES];

   /* Initialize the dot vector to the yprime vector. */
   memcpy((void *)dot, (void *)yprime, AME_NBOF_SOLVER_STATES*sizeof(double));
#endif

#if(AME_MODEL_ISEXPLICIT == 0)
   /* Initialize everything ready for potential calls to stepdn
      in submodels. */

#if(defined(AME_COSIM) && (AME_NBOF_INPUTS > 0))
   if(amesys->doInterpol) {
      if( getInputsCosimSlave(amesys->csSlave, t, input) != AME_NO_ERROR ) {
         AmeExit(1);
      }
   }
#endif

   if(isstabrun_())
   {
      t = amesys->simOptions->fixedTime;
   }
#endif

   /* Record current simulation time for ametim_(). */

   SetTimeAtThisStep(t);

   if (holdinputs_())
   {
      /* We reset artificially the time to the initial value
         to give the illusion of held inputs. */

      t = getstarttime_();
   }

   /* Assign the state variables y[] calculated by the integrator
      to the appropriate variables v[] and right calls necessary
      for that state in a case of a switch. */


   status |= (*jfunc_table[col])(amesys, t, y, dot, v, yprime, delta, col);


   UpFECount(amesys);
   
   if(status & AME_MODEL_FATAL) {
      AmeExit(1);
   }
}

static void EndOfSimulation(AMESIMSYSTEM *amesys)
{
   int n=1;
   double *y = amesys->states;
   double *v = amesys->v;
   double *Z = amesys->discrete_states;
   double *dbk_wk = amesys->pModel->dbk_wk;
   const double t = getfinaltime_();
   S_AMESubIntf sitf = {amesys, NULL, NULL, t, NULL, v, NULL};
   AMEModelStatus status = AME_MODEL_OK;
   

   (void)n;
   (void)status;

   sitf.structuralInfo = &STLI_9;
   sitf.simulationInfo = &amesys->pModel->subArray[9];
   status |= stop0_end(&sitf);
   sitf.structuralInfo = &STLI_8;
   sitf.simulationInfo = &amesys->pModel->subArray[8];
   status |= ssink_end(&sitf);
   sitf.structuralInfo = &STLI_2;
   sitf.simulationInfo = &amesys->pModel->subArray[2];
   status |= thcs1_end(&sitf);

   n = 1;
   {


      essbatcp2d01v01end_(&n, RP0, IP0, TP0, PS0, NULL, NULL, &v[11]
         , &v[111], &v[211], &v[322], NULL, NULL, NULL, NULL);
   }
   sitf.structuralInfo = &STLI_3;
   sitf.simulationInfo = &amesys->pModel->subArray[3];
   status |= thts1_end(&sitf);
   sitf.structuralInfo = &STLI_1;
   sitf.simulationInfo = &amesys->pModel->subArray[1];
   status |= cons00_end(&sitf);
}

static void ameTerminate(AMESIMSYSTEM *amesys)
{
#ifdef AME_WRITE_RUNSTAT
   if(amesys->simOptions ) {
      if(amesys->simOptions->statistics)
      {
         WriteRunStats(amesys);
      }
   }
#endif
#ifdef AME_PROCESS_TIME
   ProcessTime(2);
#endif

   /* Save state count, discontinuities and finalize the Performance Analyzer */
#ifdef AME_PERFORMANCE_ANALYZER
   if(!isfixedstepsolver_()){
      PerfAnalyzer_SaveStateCount (amesys);
      PerfAnalyzer_SaveDiscontinuities(amesys);
      PerfAnalyzer_Close(amesys);
   }
#endif

#ifdef AME_RESULT_FILE
   amesys->CloseResultFile(amesys);
#endif

   EndOfSimulation(amesys);
   AmeCallAtEnd(amesys->ameExitStatus);
   modelCleanStore(amesys->pModel);
}

#ifdef AME_EXPOSE_JACOBIAN
static int getPartialDerivatives(double *A, double *B, double *C, double *D)
{
   int res;
   AMESIMSYSTEM  *amesys = GetGlobalSystem();

   SPARSE_MATRIX *Amat, *Bmat, *Cmat, *Dmat;

#if(AME_MODEL_ISEXPLICIT == 1)
   if (amesys->tlast > TLAST_MIN)
      res = LDoLinearAnalysisOnDemand(amesys, amesys->numstates,
                                       amesys->tlast, amesys->states,
                                       &Amat, &Bmat, &Cmat, &Dmat);
#else
   if (amesys->tlast > TLAST_MIN)
      res = DDoLinearAnalysisOnDemand(amesys, amesys->neq,
                                       amesys->tlast,
                                       amesys->states, amesys->dotstates,
                                       &Amat, &Bmat, &Cmat, &Dmat);
#endif
   else
      res = 0;  /* failed: system probably not initialized */

   if(res != 0) {
      if(Amat) {
         GetMatAsDense(Amat,A);
      }
      if(Bmat) {
         GetMatAsDense(Bmat,B);
      }
      if(Cmat) {
         GetMatAsDense(Cmat,C);
      }
      if(Dmat) {
         GetMatAsDense(Dmat,D);
      }
      FreeSparseMatrix(Amat);
      FreeSparseMatrix(Bmat);
      FreeSparseMatrix(Cmat);
      FreeSparseMatrix(Dmat);
   }

   return res;
} /* getPartialDerivatives */

static int setLASettingsFromIO(int num_input_index, int num_output_index,
                              int *input_index, int *output_index, int *nbState)
{
   *nbState = AME_NBOF_EXPLICIT_STATE + AME_NBOF_IMPLICIT_STATE;

   return SetLADetailsFromIO(AME_NBOF_EXPLICIT_STATE, AME_NBOF_IMPLICIT_STATE,
                              AME_NBOF_INPUTS, AME_NBOF_OUTPUTS,
                              num_input_index, num_output_index, input_index, output_index,
                              GInputVarNum, GOutputVarNum, 0.0, 1.0, 1.0, 0.1);
}
#endif

/* ============================================================== */

static void ModelAmeExit(AMESIMSYSTEM *amesys, int status)
{
   /* Will be catch by the state machine */
   amesys->ameExitStatus = status;
   longjmp(amesys->jump_env, status);
}

#ifdef AME_INPUT_IN_MEMORY
#include "DFN_Model_Verification_.ssf.h"
static const char **getssflist(int *num_items)
{
   *num_items = savestatusflags_length;
   return savestatusflags;
}
#endif

/**************************************************************
*                                                             *
* Function load_subdata_tables reads data for lookuptables    *
* mostly/only used for realtime                               *
*                                                             *
* 0106429                                                     *
* Move the include outside of function. The include now       *
* contains one function per table and a function that calls   *
* them all. This reduces the risk that a compiler crashes due *
* to a huge function.                                         *
**************************************************************/
#ifdef AME_TABLES_IN_MEMORY
#include "DFN_Model_Verification_.subdata.h"
#endif

static void load_subdata_tables(void)
{
#ifdef AME_TABLES_IN_MEMORY
   add_all_tables_to_memory();
#endif
}

/***********************************************************
   Purpose  :  Return Simcenter Amesim version used to generate the model C code
               It allows the client to update interface management for
               backward compatibility.
   Author	:  J.Andre
   Creation :  2016 - 09 - 05
   Inputs   :  None
   Outputs  :  Simcenter Amesim version
   Revision :
************************************************************/
static unsigned int AmesysGetVersion()
{
	/* Returned number indicates 10000* main verion + 100* SL version + minor */
   /* Eg. Rev15     (15.0.0)  => 150000 */
   /* Eg. Rev15SL1  (15.1.0)  => 150100 */
   /* Eg. Rev15.0.1 (15.0.1)  => 150001 */

   return AMEVERSION;
}

/***********************************************************
   Purpose  :  Return SoldTo ID which Simcenter Amesim model has been generated.
   Author	:  J.Andre
   Creation :  2017 - 02 - 13
   Inputs   :  None
   Outputs  :  SoldToID
   Revision :
************************************************************/
static const char* getSoldToID()
{
   return "4553207";
}

#ifdef AME_INPUT_IN_MEMORY
#include "DFN_Model_Verification_.globalparams.h"
#endif

/***********************************************************
   Purpose  : Load and evaluate model parameters from files
   Author   : J.Andre
   Created  : 2016 - 09 - 08
   Inputs   :
      amesys  : system
      errmsg  : error message
   Outputs  : Error code
   Revision :
************************************************************/
static AMESystemError loadModelParamFromDisk(AMESIMSYSTEM *amesys, AMESystemError *gpError,  AMESystemError *lpError, char *errmsg)
{
   AMESystemError ret;
   *gpError = AME_NO_ERROR;
   *lpError = AME_NO_ERROR;

   ret = AmeReadGPFile(amesys);

   if(ret == AME_NO_ERROR) {
      *gpError = AmeEvalGlobalParamList(amesys, 1, errmsg);
      *lpError = loadParameterFromFile(amesys->pModel, GetDataFileName(), errmsg);
   }
   return ret;
}

#ifdef AME_INPUT_IN_MEMORY

/***********************************************************
   Purpose    : Load and evaluate model parameters from memory
   Author	  : J.Andre
   Created on : 2016 - 09 - 08
   Inputs	  :
      amesys  : system
      errmsg  : error message
   Outputs	  : Parameter error code
   Revision   :
************************************************************/
static AMESystemError loadModelParamFromMemory(AMESIMSYSTEM *amesys, AMESystemError *gpError,  AMESystemError *lpError, char * errmsg)
{
#include "DFN_Model_Verification_.data.h"

   ameAddGlobalParamsFromMemory(amesys,errmsg);

   if(amecheckversion(AMESIMRUNTIMEVERSION, __TIME__, __DATE__, NULL)) {
      amefprintf(stderr, "A problem with incompatible versions of the AMESim runtime library has been found.");
   }

   *gpError = AmeEvalGlobalParamList(amesys, 1, errmsg);
   *lpError = loadParameterFromDataTable(amesys->pModel, allparams, errmsg);

   return AME_NO_ERROR;
}

#endif

/***********************************************************
   Purpose    : Load and evaluate model parameters
   Author	  : J.Andre
   Created on : 2016 - 09 - 08
   Inputs	  :
      amesys  : system
      errmsg  : error message
   Outputs	  : Parameter error code
   Revision   :
************************************************************/
static AMESystemError loadModelParameters(AMESIMSYSTEM *amesys)
{
   AMESystemError res = AME_PARAMETER_ERROR;
   char errmsg[PATH_MAX+128];
   AMESystemError ret_gp = AME_NO_ERROR;
   AMESystemError ret_lp = AME_NO_ERROR;

   errmsg[0] = '\0';

#ifdef AME_INPUT_IN_MEMORY
#ifdef AME_RT_CAN_READ_FILE
   res = loadModelParamFromDisk(amesys, &ret_gp, &ret_lp, errmsg);

   if (res != AME_NO_ERROR) {
      /* If the file is not there - we say nothing */
      if (res != AME_PARAM_FILE_OPEN_ERROR) {
         amefprintf(stderr,"%s",errmsg);
         amefprintf(stderr,"loadParameterFromFile> %s\n",errmsg);
         ClearGPs();
      }
   }
   else {
      amefprintf(stderr,"Using data from disk (%s)\n",GetDataFileName());
   }
#endif
   if(res != AME_NO_ERROR) {
      /* Read all from memory */
      res = loadModelParamFromMemory(amesys, &ret_gp, &ret_lp, errmsg);
      SetGlobalParamReadFile(0);
   }
#else
   /* Read all from disk */
   res = loadModelParamFromDisk(amesys, &ret_gp, &ret_lp, errmsg);
#endif

   if( (res != AME_NO_ERROR) || (ret_gp != AME_NO_ERROR) || (ret_lp != AME_NO_ERROR) ) {
      amefprintf(stderr,"%s",errmsg);

      if( (res != AME_NO_ERROR) || (ret_lp != AME_NO_ERROR) ) {
         res = AME_GLOBAL_PARAMETER_ERROR;
      }
   }
   return res;
}

static AMESystemError Input(AMESIMSYSTEM *amesys)
{
   int retval;

   /* Load data files for submodels */
   load_subdata_tables();

   /* Load parameters for submodels */
   retval = loadModelParameters(amesys);

   /* Ensure parameters seen by RT is initialized correctly */
#ifdef AME_MEMORY_ACCESS_RT_EXPORT
   RT_Get_Watch_Param(amesys);
#endif

   return retval;
}

static int ameSetOptions(AMESIMSYSTEM *amesys,
                         double tsaveinc,
                         double maxstepsize,
                         double tolerance,
                         int errorcontrol,
                         int writelevel,
                         int extradisconprint,
                         int runstats,
                         int theruntype,
                         int thesolvertype)
{
   amesys->simOptions->errorType = errorcontrol;
   amesys->simOptions->tol = tolerance;
   amesys->simOptions->rStrtp = extradisconprint;
   amesys->simOptions->statistics = runstats;
   amesys->simOptions->solverType = thesolvertype;
   amesys->simOptions->runType = theruntype;
   amesys->simOptions->iWrite = writelevel;
   amesys->simOptions->tInc = tsaveinc;
   amesys->simOptions->hMax = maxstepsize;

   /* Copy sim option to share with libraries before to modify it */
   memcpy(amesys->sharedSimOptions, amesys->simOptions, sizeof(SIMOptions));

   if(amesys->simOptions->solverType) {
      /* It is the cautious option. The maximum time step
         should not exceed the print interval. */
      setmaxstep_(&amesys->simOptions->tInc);
   }

#if( AME_MODEL_ISEXPLICIT == 1) && (AME_NBOF_EXPLICIT_STATE == 0 )
   if(maxstepsize > tsaveinc) {
      amefprintf(stderr, "Since the model has no state variable,\n");
      amefprintf(stderr, "the maximum time step has been reduced to %gs.\n", tsaveinc);
      setmaxstep_(&amesys->simOptions->tInc);
   }
#endif

   SetInitPrintIntervalFromSimOpts(amesys);

   ValidateRuntype(theruntype);

   ameSetupTolerance(amesys->simOptions);

   return 1;
}

static int ameSetOptionsFixed(AMESIMSYSTEM *amesys,
                              double printinterval,
                              int fixed_type,
                              int fixedOrder,
                              double fixed_h,
                              int run_type)
{
   amesys->simOptions->iWrite = 2;

   ValidateRuntype(run_type);

	/* Ensure that runflag StabilizingRun=0. It might have been set to true */
	/* due to a previous selection for the variable step integrator. */
   ClearStabilizingRun();

   amesys->simOptions->fixedOrder = fixedOrder;
   amesys->simOptions->fixedStep  = 1; /* Yes - fixed step */
   amesys->simOptions->fixedH     = fixed_h;

   amesys->simOptions->tInc =  printinterval;
   amesys->simOptions->rStrtp = 0;  /* No discontinuity printout using fixed step solver */

   amesys->simOptions->fixedType  = fixed_type;
   SetIsUsingFixedSolver(( fixed_type == 1)*100 +  (fixed_type != 1)*200 + fixedOrder);

   SetFixedTimeStep(fixed_h);

   return 1;
}

static int ameInputs(AMESIMSYSTEM *amesys, int numInputs, const double *inputARG)
{
   if(numInputs != amesys->numinputs)
   {
      char error_message[256];
      sprintf(error_message, "AMEInputs> Expected %d inputs but got %d\n", amesys->numinputs, numInputs);
      DisplayMessage(error_message);
      return 0;
   }
#if (AME_NBOF_INPUTS > 0)
   memcpy(amesys->inputs, inputARG, amesys->numinputs*sizeof(double) );
#endif
   return 1;
}

static void doAssembly(AMESIMSYSTEM *amesys)
{
   if (IsAssemblyNecessary_())
   {
      double time = getstarttime_();
      double tmp[AME_NBOF_SOLVER_STATES];
      int local_flag;

      /* Perform the assembly. */
      amesys->consflag = 1;
      local_flag = 0;
#if(AME_MODEL_ISEXPLICIT == 1)
      amesys->FuncEval(amesys, time, amesys->states, tmp, NULL, &local_flag);
#else
      amesys->res(amesys, time, amesys->states, amesys->dotstates, tmp, &local_flag);
#endif
      amesys->first_call = 1;

      amesys->consflag = 2;
      local_flag = 0;
#if(AME_MODEL_ISEXPLICIT == 1)
      amesys->FuncEval(amesys, time, amesys->states, tmp, NULL, &local_flag);
#else
      amesys->res(amesys, time, amesys->states, amesys->dotstates, tmp, &local_flag);
#endif
      amesys->first_call = 1;
      amesys->consflag = 0;
   }
}

static int ameEvalTstart(AMESIMSYSTEM *amesys, const double *modelInputs, double *modelOutputs)
{
#ifndef AMERT
   double time = getstarttime_();

   ameInputs(amesys, AME_NBOF_INPUTS, modelInputs);

   doAssembly(amesys);

   /* Initialize, maybe perform an initialising run */

   if(isstabrun_())
   {
      amesys->simOptions->fixedTime = time;
   }
   amesys->simOptions->stabilOption += 4*amesys->simOptions->solverType;

#if(AME_MODEL_ISEXPLICIT == 1)

   if(!IntegrateInit(amesys, time, time))
   {
      return 0;
   }
#else
   amesys->internal_discont = 1;

   DIntegrateInit(amesys, AME_NBOF_EXPLICIT_STATE, time, getfinaltime_(), amesys->simOptions->tInc, amesys->states,
                  amesys->dotstates, amesys->simOptions->hMax, AME_NBOF_SOLVER_STATES, amesys->iwork, amesys->simOptions->reltol, amesys->simOptions->abstol, amesys->simOptions->rStrtp, LIW, LRW, amesys->simOptions->statistics,amesys->simOptions->stabilOption, amesys->simOptions->iWrite, amesys->simOptions->minimalDiscont, Gis_constraint);

   if(isstabrun_())
   {
      /* HELP !!!! */
   }
#endif

#if (AME_NBOF_OUTPUTS > 0)
   memcpy(modelOutputs, amesys->outputs, amesys->numoutputs*sizeof(double) );
#endif
   amesys->tlast = time;

   return 1;
#else
   char error_message[256];
   sprintf(error_message, "ameEvalTstart> Should never be called for real-time simulation\n");
   DisplayMessage(error_message);
   return 0;
#endif
}

static int ameSetUpLockedStatus(AMESIMSYSTEM *amesys)
{
#ifdef AME_INPUT_IN_MEMORY
#include "DFN_Model_Verification_.lock.h"
   if(0 != SetUpLockedStatesFromMemory(amesys, lockedstates_length, lockedstates_array))
   {
      amefprintf(stderr,"Failed to set the locked states status.\n");
   }
#else
   SetUpLockedStates(GetCircuitName());
#endif
   return 0;
}

static int ameInitializeConditions(AMESIMSYSTEM *amesys)
{
#ifdef AME_VSOLVER_ACCEPTED
   double time = amesys->simOptions->tStart;

   /* Initialise some static variables */
   setfinaltime_(amesys->simOptions->tFinal);

   amesys->first_call=1;  /* should this be done or not ?*/
   amesys->internal_discont = 1;

   amesys->tlast = TLAST_MIN;

   memset(amesys->ecount,0,amesys->numstates*sizeof(int));
   memset(amesys->dotstates,0,amesys->numstates*sizeof(double));

#if(AME_MODEL_ISEXPLICIT == 0)
   memset(amesys->iwork,0,LIW*sizeof(int));
#endif
   /*  The following statement covers the case where there are
       no state variables y. */
#if( AME_NBOF_EXPLICIT_STATE == 0 )
   amesys->states[0] = 0.0;
#endif

   /* Call Input to read submodel and simulation parameters. */
   if(Input(amesys) != AME_NO_ERROR) return 0;
   modelSetInitValues(amesys->pModel, amesys->states, amesys->discrete_states);

   /* Register print interval that maybe used bys some submodels */
   SetInitPrintIntervalFromSimOpts(amesys);

   setstarttime_(time);

   /* Call pre-initialize function */

   PreInitialize(amesys,amesys->states);

#ifndef AME_INPUT_IN_MEMORY
   if( NeedReloadInputFiles() != 0 )
   {
      ClearGPs();
      if(Input(amesys) != AME_NO_ERROR) return 0;
      modelSetInitValues(amesys->pModel, amesys->states, amesys->discrete_states);
      ClearReloadedFiles();
   }
#endif

   /* Call initialize subroutine to set con and icon array members */

   Initialize(amesys,amesys->states);

   /* Overwriting initial state values with requests emitted by */
   /* submodels that have a more global view (cf. register.c mechanism) */
   /* Can also fire some callbacks to 'fix' float and integer store */
   OverloadStatesWithRegister(amesys, amesys->states, SVREGISTER_DEFAULT);

   CheckSimParams(amesys, &amesys->simOptions->abstol,
                  &amesys->simOptions->reltol,
                  &amesys->simOptions->hMax);

#ifdef AME_RESULT_FILE
   /*  Open file for results. */
   amesys->AmeReadFile(amesys, &time, amesys->states);
#endif

   if(isconrun_() || isusefinval_())
   {
      updateStatesFromModel(amesys, amesys->states, AME_CONTINUOUS_STATE|AME_DISCRETE_STATE);
   }

   /* Read linear analysis specification. */
#ifndef FMI
   SetLADetails(GetLAFileName(), amesys->numstates, amesys->numvars, time,  amesys->simOptions->reltol, amesys->simOptions->abstol, getfinaltime_()-time);

   /* Remove old err file */

   remove(GetErrorFileName());

   /* Initialize the Performance analyzer */
   if(!isfixedstepsolver_()) {
      PerfAnalyzer_Init(amesys, time, getfinaltime_() );
   }
#endif
   if(isconrun_())
      setstarttime_(time);

   /* Set the locked states info */
   ameSetUpLockedStatus(amesys);

   return 1;
#else
   char error_message[256];
   sprintf(error_message, "AMEInitializeConditions> Should never be called for real-time simulation\n");
   DisplayMessage(error_message);
   return 0;
#endif
}

#if(AME_MODEL_ISEXPLICIT == 1)
static int ameEvalTstartFixed(AMESIMSYSTEM *amesys, const double *modelInputs, double *modelOutputs)
{
   double time = getstarttime_();

   ameInputs(amesys, AME_NBOF_INPUTS, modelInputs);

   doAssembly(amesys);

   amesys->tlast = time;

   /* Evaluation of the model at tStart */
   {
      int local_flag = 0;
      SetIsPrinting(amesys);
      amesys->FuncEval(amesys, time, amesys->states, amesys->yh, NULL, &local_flag);
      ClearIsPrinting(amesys);

#if defined(AME_RESULT_FILE) && !defined(STANDALONESIMULATOR)
      amesys->OutputResults(amesys, amesys->tlast);
      amesys->resultFileStructPtr->lastprinttime = amesys->tlast;
#endif

      /* Now, amesys->first_call == 0 (set at the end of FunctionEval) */
   }

#if (AME_NBOF_OUTPUTS > 0)
   memcpy(modelOutputs, amesys->outputs,amesys->numoutputs*sizeof(double) );
#endif
   amesys->tlast = time;

#ifdef AME_PROCESS_TIME
   /* Initialization of time timers */
   ProcessTime(0);
#endif

   return 1;
}

static int ameInitializeConditionsFixed(AMESIMSYSTEM *amesys)
{
   double start_time = amesys->simOptions->tStart;

   assert(amesys);

   amesys->first_call=1;  /* should this be done or not ?*/

   amesys->tlast=TLAST_MIN;

   /* Init solver */
   memset(amesys->yh,0,(AME_NBOF_SOLVER_STATES*13)*sizeof(double));

   InitFixedStepIntegrate(amesys);

   setfinaltime_(amesys->simOptions->tFinal);

   /* Call Input to read submodel and simulation parameters. */
   if(Input(amesys) != AME_NO_ERROR) return 0;
   modelSetInitValues(amesys->pModel, amesys->states, amesys->discrete_states);

   SetInitPrintIntervalFromSimOpts(amesys);

   setstarttime_(start_time);

   /* Call pre-initialize function */

   PreInitialize(amesys,amesys->states);

#ifndef AME_INPUT_IN_MEMORY
   if( NeedReloadInputFiles() != 0 )
   {
      ClearGPs();
      if(Input(amesys) != AME_NO_ERROR) return 0;
      modelSetInitValues(amesys->pModel, amesys->states, amesys->discrete_states);
      ClearReloadedFiles();
   }
#endif

   /* Call initialize subroutine to set con and icon array members */

   Initialize(amesys,amesys->states);

   /* Overwriting initial state values with requests emitted by */
   /* submodels that have a more global view (cf. register.c mechanism) */
   /* Can also fire some callbacks to 'fix' float and integer store */
   OverloadStatesWithRegister(amesys, amesys->states, SVREGISTER_DEFAULT);

#ifdef AME_RESULT_FILE
   /*  Open file for results. */
   amesys->AmeReadFile(amesys, &start_time, amesys->states);
#endif

   if(isconrun_() || isusefinval_())
   {
      updateStatesFromModel(amesys, amesys->states, AME_CONTINUOUS_STATE|AME_DISCRETE_STATE);
   }

   /* Set the locked states info */
   ameSetUpLockedStatus(amesys);

   if(isconrun_()) {
      setstarttime_(start_time);
   }

   return 1;
}
#endif

/*=============================================================================*/

/*=============================================================================*/

/***********************************************************
   Purpose    : Test request acceptance
   Author	  : J.Andre
   Created on : 2016 - 09 - 05
   Inputs	  :
      event   : entry event
   Outputs	  :
      AME_NO_ERROR : event accepted
      AME_SEQUENCE_ERROR : event refused
   Revision   :
************************************************************/
static AMESystemError AmesysControlRequest(AMESIMSYSTEM *amesys, AMESystemCmd event)
{
   AMESystemError res = AME_NO_ERROR;

   if(!amesys) {
      if(event == AME_CMD_GET_MODEL_INFO) {
         return AME_NO_ERROR;
      }
      return AME_SEQUENCE_ERROR;
   }

   switch(event) {
      case AME_CMD_RELEASE: {
         if( !(amesys->systemState & (AMESTATE_TERMINATED | AMESTATE_FATAL | AMESTATE_INSTANTIATED)) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_SETUP: {
         if( !(amesys->systemState & AMESTATE_INSTANTIATED) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_INITIALIZE: {
         if(amesys->systemState != AMESTATE_READY) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_TERMINATE: {
         if( !(amesys->systemState & (AMESTATE_RUN | AMESTATE_READY | AMESTATE_ERROR)) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_TSTART: {
         if( !(amesys->systemState & AMESTATE_INITIALIZED) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_STEP: {
         if( !(amesys->systemState & AMESTATE_RUNNING) ) {
            res = AME_SEQUENCE_ERROR;
         }
         else {
            amesys->systemState |= AMESTATE_STEP_IN_PROGRESS;
         }
      }
      break;
      case AME_CMD_RESTART: {
         /* At this time, it is not still implemented */
         /* Depends of clean-up in terminated state and static variables */
         res = AME_SEQUENCE_ERROR;
      }
      break;
      case AME_CMD_GET_MODEL_INFO: {
         res = AME_NO_ERROR;
      }
      break;
      case AME_CMD_SET_MODEL_PARAM_TUNABLE: {
         if( !(amesys->systemState & (AMESTATE_READY | AMESTATE_RUN)) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_SET_MODEL_PARAM:
      case AME_CMD_SET_RUN_PARAM:
      case AME_CMD_SET_SOLVER_PARAM: {
         if(amesys->systemState != AMESTATE_READY) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_GET_MODEL_PARAM:
      case AME_CMD_GET_SOLVER_PARAM:
      case AME_CMD_GET_RUN_PARAM: {
         if( !(amesys->systemState & (AMESTATE_READY | AMESTATE_RUN | AMESTATE_ERROR)) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_REQ_RUN_INTERRUPT: {
         if( !(amesys->systemState & (AMESTATE_INSTANTIATED | AMESTATE_READY | AMESTATE_INITIALIZED | AMESTATE_RUNNING)) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_SET_ENV: {
         if( !(amesys->systemState & AMESTATE_INSTANTIATED) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      case AME_CMD_FUNCEVAL: {
         if( !(amesys->systemState & AMESTATE_RUNNING) ) {
            res = AME_SEQUENCE_ERROR;
         }
      }
      break;
      default:
         res = AME_SEQUENCE_ERROR;
      break;
   }

   return res;
}

/***********************************************************
   Purpose    : Update state and manage result of request
   Author	  : J.Andre
   Created on : 2016 - 09 - 05
   Inputs	  :
      event   : entry event
      reqResult : result of request achievement
   Outputs	  :
      AME_NO_ERROR : event accepted
      AME_SEQUENCE_ERROR : event refused
   Revision   :
************************************************************/
static AMESystemError AmesysUpdateState(AMESIMSYSTEM *amesys, AMESystemCmd event, AMESystemError reqResult)
{
   unsigned int newState;
   AMESystemError res;

   if(!amesys) {
      return AME_SEQUENCE_ERROR;
   }

   newState = amesys->systemState;   /* Default: no change in state */
   res = reqResult;                  /* Default: no change in result */

   switch(event) {
      case AME_CMD_INSTANTIATE: {
         if(reqResult != AME_NO_ERROR) {
            newState = AMESTATE_FATAL;
         }
         else {
            newState = AMESTATE_INSTANTIATED;
         }
      }
      break;
      case AME_CMD_SETUP: {
         if(reqResult != AME_NO_ERROR) {
            newState = AMESTATE_FATAL;
         }
         else {
            newState = AMESTATE_READY;
         }
      }
      break;
      case AME_CMD_INITIALIZE: {
         if(reqResult != AME_NO_ERROR) {
            newState = AMESTATE_ERROR;
         }
         else {
            newState = AMESTATE_INITIALIZED;
         }
      }
      break;
      case AME_CMD_TERMINATE: {
         if(reqResult != AME_NO_ERROR) {
            amesys->systemState = AMESTATE_TERMINATED; /* Avoid automatic call to ameterminate */
            newState = AMESTATE_FATAL;
         }
         else {
            newState = AMESTATE_TERMINATED;
         }
      }
      break;
      case AME_CMD_TSTART: {
         if(reqResult != AME_NO_ERROR) {
            newState = AMESTATE_ERROR;
         }
         else {
            newState = AMESTATE_RUNNING;
         }
      }
      break;
      case AME_CMD_STEP: {
         if(reqResult != AME_NO_ERROR) {
            /* test ameExitStatus */
            if(reqResult == AME_EXIT_ERROR) {
               if(amesys->ameExitStatus == 0) {
                  /* Simulation stopped early but normally */
                  amesys->requestinterrupt = 0;
                  newState = AMESTATE_STOPPED_EARLY;
                  res = AME_NO_ERROR;
               }
               else
               {
                  newState = AMESTATE_ERROR;
               }
            }
            else {
               newState = AMESTATE_ERROR;
            }
         }
         else if(amesys->requestinterrupt) {
            amesys->requestinterrupt = 0;
            newState = AMESTATE_STOPPED_END;
         }
         newState &= ~AMESTATE_STEP_IN_PROGRESS;
      }
      break;
      case AME_CMD_REQ_RUN_INTERRUPT:
      break;
      case AME_CMD_FUNCEVAL: {
         if(reqResult != AME_NO_ERROR) {
            /* test ameExitStatus */
            if(reqResult == AME_EXIT_ERROR) {
               if(amesys->ameExitStatus == 0) {
                  /* Simulation stopped early but normally */
                  newState = AMESTATE_STOPPED_EARLY;
                  res = AME_NO_ERROR;
               }
               else
               {
                  newState = AMESTATE_ERROR;
               }
            }
            else {
               newState = AMESTATE_ERROR;
            }
         }
      }
      break;
      default:
      /* No state change, no exception to catch, just pass result */
      break;
   }

   if(amesys->systemState != newState) {
      if(newState == AMESTATE_FATAL) {
         if(amesys->systemState & (AMESTATE_RUN | AMESTATE_READY | AMESTATE_ERROR)) {
            /* Terminating the simulation */
            ameTerminate(amesys);
         }
      }

#if !defined(STANDALONESIMULATOR)
      if(newState & (AMESTATE_FATAL | AMESTATE_ERROR)) {
         if(amesys->systemState & AMESTATE_RUN) {
            amefprintf(stderr, "Simcenter Amesim model: simulation failed.\n");
         }
         else if(amesys->systemState & AMESTATE_IDLE) {
            amefprintf(stderr, "Simcenter Amesim model: instantiation failed.\n");
         }
         else if(amesys->systemState & AMESTATE_READY) {
            amefprintf(stderr, "Simcenter Amesim model: initialization failed.\n");
         }
      }
      else if(newState & AMESTATE_INITIALIZED) {
         amefprintf(stdout, "Simcenter Amesim model: initialization done.\n");
      }
      else if(newState & AMESTATE_TERMINATED) {
         amefprintf(stdout, "Simcenter Amesim model: simulation terminated.\n");
      }
      else if((newState & AMESTATE_RUNNING) && (amesys->systemState & AMESTATE_INITIALIZED)) {
         amefprintf(stdout, "Simcenter Amesim model: simulation started.\n");
      }
#endif

      /* Update state */
      amesys->systemState = newState;
   }

   if(amesys->systemState == AMESTATE_FATAL) {
      /* Greedy error */
      res = AME_FATAL_ERROR;
   }

   return res;
}

/***********************************************************
   Purpose    : Instantiate the system
   Author	  : J.Andre
   Created on : 2016 - 09 - 08
   Inputs	  : None
   Outputs	  : Error code
   Revision   :
************************************************************/
static AMESystemError AmesysInstantiate(AMESIMSYSTEM **amesysPtr)
{
   int jump_ret;
   AMESIMSYSTEM *amesys;
   AMESystemError result = AME_FATAL_ERROR;

   S_AME_Model *pModel;

   if(*amesysPtr != NULL) {
      return AME_SEQUENCE_ERROR;
   }

   result = createModel(&pModel, &GmodelDef, GParamInfo, GVarInfo, GsubmodelNameArray,
                        GcontStateVarNum, GdiscStateVarNum, GFixedVarNum);

   if(result == AME_NO_ERROR) {
#if(AME_MODEL_ISEXPLICIT == 1)
      amefprintf(stdout, "Instantiating a system with %d unknowns.\n", AME_NBOF_EXPLICIT_STATE);
#else
      amefprintf(stdout, "Instantiating a system with %d unknowns.\n", AME_NBOF_SOLVER_STATES);
#endif
      if (strcmp(soldToId,"not available") != 0)
         amefprintf(stdout, "Simcenter Amesim version: %s (%s).\n", "2404", soldToId);
      else
         amefprintf(stdout, "Simcenter Amesim version: %s.\n", "2404");
      result = createAMESystem(&amesys, pModel, AME_NBOF_SOLVER_STATES, AMEVERSION);
   }
#if (AME_NB_SUBMODEL_REF>0)
   if(result == AME_NO_ERROR) {
      int idx_sub;
      for(idx_sub = 0; idx_sub < AME_NB_SUBMODEL_REF; idx_sub++) {
         S_AMESubSimuInfo info;
         info.rp = SUBSIMU[idx_sub][0][0] > 0 ? &pModel->realParamArray[SUBSIMU[idx_sub][0][1]] : NULL;
         info.ip = SUBSIMU[idx_sub][1][0] > 0 ? &pModel->integerParamArray[SUBSIMU[idx_sub][1][1]] : NULL;
         info.tp = (const char **)(SUBSIMU[idx_sub][2][0] > 0 ? &pModel->textParamArray[SUBSIMU[idx_sub][2][1]] : NULL);
         info.c = SUBSIMU[idx_sub][3][0] > 0 ? &pModel->realStoreArray[SUBSIMU[idx_sub][3][1]] : NULL;
         info.ic = SUBSIMU[idx_sub][4][0] > 0 ? &pModel->intStoreArray[SUBSIMU[idx_sub][4][1]] : NULL;
         info.ps = SUBSIMU[idx_sub][5][0] > 0 ? &pModel->pointerStoreArray[SUBSIMU[idx_sub][5][1]] : NULL;
         info.na = pModel->ptrNetWorkArray;
         result |= setSubSimuParam(pModel, idx_sub, &info);
      }
   }
#endif

   if(result == AME_NO_ERROR) {
      if( (jump_ret = setjmp(amesys->jump_env)) == 0) { /* ~try */
         SetGlobalSystem(amesys);

#ifdef AME_INPUT_IN_MEMORY
         amesys->getssflist = getssflist;
#endif
         amesys->consflag = 0;

#if(AME_MODEL_ISEXPLICIT == 1)
         amesys->FuncEval = localFuncEval;
         amesys->JFuncEval = localJFuncEval;
#else
         amesys->res = localFuncEval;
         amesys->Jres = localJFuncEval;
#endif
         amesys->AmeExit = ModelAmeExit;

         amesys->ameExitStatus = 0;

         /* Set input directory to current directory */
         AmeSetInputDir(amesys,NULL);

         /* Set output directory to current directory */
         AmeSetOutputDir(amesys,NULL);

         /* Set base name of input files, no extension */
         AmeSetModelBaseName(amesys,"DFN_Model_Verification_", NULL);

         result = AME_NO_ERROR;
      }
      else { /* Catch AmeExit */
         result = AME_EXIT_ERROR;
      }
   }

   if(result == AME_NO_ERROR) {
      /* Update state and result */
      result =  AmesysUpdateState(amesys, AME_CMD_INSTANTIATE, result);
   }

   if(result != AME_NO_ERROR) {
      deleteAMESystem(&amesys);
      SetGlobalSystem(NULL);
   }
   else {
      *amesysPtr = amesys;
   }

   return result;
}

static AMESystemError AmesysTerminate(AMESIMSYSTEM *amesys)
{
   int jump_ret;
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_TERMINATE);
   if(res != AME_NO_ERROR) {
      /* Request not accepted */
      return res;
   }

   if(res == AME_NO_ERROR) { /* Request accepted */
      if( (jump_ret = setjmp(amesys->jump_env)) == 0) { /* ~try */
         ameTerminate(amesys);
      }
      else { /* Catch AmeExit */
         res = AME_EXIT_ERROR;
      }
   }

   /* Update state and result */
   res =  AmesysUpdateState(amesys, AME_CMD_TERMINATE, res);

   return res;
}

static AMESystemError AmesysRelease(AMESIMSYSTEM **amesysPtr)
{
   AMESystemError res = AME_NO_ERROR;
   if(*amesysPtr) {
      SetGlobalSystem(*amesysPtr);
      res = AmesysControlRequest(*amesysPtr, AME_CMD_RELEASE);

      if(res == AME_NO_ERROR) { /* Request accepted */
         AmeSignalModelUnload();
         res = deleteAMESystem(amesysPtr);
         SetGlobalSystem(NULL);
      }
   }
   return res;
}

/***********************************************************
   Purpose    : Go in Ready state to be able receive external
                initialization of model and simulation
   Author	  : J.Andre
   Created on : 2016 - 09 - 08
   Inputs	  : loadParam: if true, model parameters are read
   Outputs	  : Error code
   Revision   :
************************************************************/
static AMESystemError AmesysSetUp(AMESIMSYSTEM *amesys, const int loadParam)
{
   int jump_ret;
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SETUP);

   if(res != AME_NO_ERROR) {
      /* Request not accepted */
      return res;
   }

   if( (jump_ret = setjmp(amesys->jump_env)) == 0) { /* ~try */
      amesys->ameExitStatus = 0;

      /* Construct file names */
      AmeConstructFileName(amesys);

      /* Read sim file */
      {
         SIMOptions opts;

#ifndef AME_INPUT_IN_MEMORY
         char errMsg[PATH_MAX+128];
         int result = readsimfile(&opts, GetSimFileName(), errMsg);
#else
         int result = readsimfromchararrays(&opts, simparams, simparams_length);
#endif

         if(result != 0) {

            /* Initialyze Amesystem SIMOptions */
            memcpy(amesys->simOptions,&opts,sizeof(SIMOptions));

#ifdef AME_RESULT_FILE
            amesys->simOptions->outoff = 0;
#else
            amesys->simOptions->outoff = 1;
#endif

#ifdef AME_PERFORMANCE_ANALYZER
            ALA_Setparam(opts.autoLA, 1, opts.autoLAstep);
            DISCLOG_SetParam(1);
#endif
         }
         else {
            res = AME_SETUP_ERROR;
         }
      }

      if(loadParam) {
         /* Load parameters */
         loadModelParameters(amesys);
      }

   }
   else { /* Catch AmeExit */
      res = AME_EXIT_ERROR;
   }

   /* Update state and result */
   res =  AmesysUpdateState(amesys, AME_CMD_SETUP, res);

   return res;
}

/***********************************************************
   Purpose    : Initialize the model
   Author	  : J.Andre
   Created on : 2016 - 09 - 08
   Inputs	  : None
   Outputs	  : Error code
   Revision   :
************************************************************/
static AMESystemError AmesysInitialize(AMESIMSYSTEM *amesys)
{
   int jump_ret;
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_INITIALIZE);

   if(res != AME_NO_ERROR) {
      /* Request not accepted */
      return res;
   }

   if( (jump_ret = setjmp(amesys->jump_env)) == 0) { /* try */
      if(amesys->simOptions->runType & 0x20) {
         /* fixed step initialization */
#if(AME_MODEL_ISEXPLICIT == 1)
         ameSetOptionsFixed(amesys, amesys->simOptions->tInc, amesys->simOptions->fixedType,
            amesys->simOptions->fixedOrder, amesys->simOptions->fixedH, amesys->simOptions->runType);

         if(!ameInitializeConditionsFixed(amesys)) {
            res = AME_INITIALIZE_ERROR;
         }
#else
         amefprintf(stderr,"It is not possible to use a fixed step solver\nfor implicit systems.\n");
         res = AME_INITIALIZE_ERROR;
#endif
      }
      else {
#ifdef AME_VSOLVER_ACCEPTED
         /* variable step initialization */
         ameSetOptions(amesys, amesys->simOptions->tInc, amesys->simOptions->hMax, amesys->simOptions->tol,
            amesys->simOptions->errorType, amesys->simOptions->iWrite, amesys->simOptions->rStrtp,
            amesys->simOptions->statistics, amesys->simOptions->runType, amesys->simOptions->solverType);

         if(!ameInitializeConditions(amesys)) {
            res = AME_INITIALIZE_ERROR;
         }
#else
         amefprintf(stderr,"It is not possible to use a variable step solver\nfor this interface.\n");
         res = AME_INITIALIZE_ERROR;
#endif
      }

#if defined(AME_MEMORY_ACCESS_RT_EXPORT)
#if (NB_WATCH_VAR>0)
         RT_Get_Watch_Var(amesys);
#endif
#endif

   }
   else { /* Catch AmeExit */
      res = AME_EXIT_ERROR;
   }

   /* Update state and result */
   res =  AmesysUpdateState(amesys, AME_CMD_INITIALIZE, res);

   return res;
}

#if(AME_MODEL_ISEXPLICIT == 1)
static void doAFixedStep(AMESIMSYSTEM *amesys, double time)
{
   double timerange;
   double actual_timestep;
   int stepratio;
   int stepratio_ceil;
   int stepratio_floor;
   int i=0;
   int zero=0;
   double tinc;
   int isTimeForPrint=0;
   double next_print_time;

   if (amesys->first_call)
   {
      SetIsPrinting(amesys);
      amesys->FuncEval(amesys, amesys->tlast, amesys->states, amesys->yh, NULL, &zero);
      ClearIsPrinting(amesys);

#if defined(AME_RESULT_FILE) && !defined(STANDALONESIMULATOR)
      amesys->OutputResults(amesys, amesys->tlast);
      amesys->resultFileStructPtr->lastprinttime = amesys->tlast;
#endif
   }

   timerange = time - amesys->tlast;

   if(timerange <= 0.0)
   {
      return;
   }
   if(amesys->simOptions->fixedH > 0.0)
   {
      stepratio = stepratio_ceil = (int)ceil(timerange/amesys->simOptions->fixedH);
      stepratio_floor = (int)floor(timerange/amesys->simOptions->fixedH);

      actual_timestep = timerange/(double)stepratio_ceil;

      if(fabs(actual_timestep-amesys->simOptions->fixedH) > 0.001*amesys->simOptions->fixedH)
      {
         if(stepratio_floor == 0)
         {
#ifdef AMEDEBUG
            amefprintf(stdout,"skipping %14.8e  range= %14.8e  actual_timestep=%14.8e stepratio_ceil=%d   stepratio_floor=%d\n",time, timerange, actual_timestep, stepratio_ceil,stepratio_floor);
#endif
            return;
         }

#ifdef AMEDEBUGw
         amefprintf(stdout,"using floor\n");
         amefprintf(stdout,"timerange=%14.8e\n", timerange);
         amefprintf(stdout,"actual_timestep=%14.8e\n", actual_timestep);
         amefprintf(stdout,"amesys->simOptions->fixedH=%14.8e\n", amesys->simOptions->fixedH);
         amefprintf(stdout,"fabs(actual_timestep-amesys->simOptions->fixedH)=%14.8e\n", fabs(actual_timestep-amesys->simOptions->fixedH));
         amefprintf(stdout,"stepratio_floor=%d\n", stepratio_floor);
         amefprintf(stdout,"stepratio_ceil=%d\n", stepratio_ceil);
#endif
         actual_timestep = timerange/(double)stepratio_floor;
         stepratio = stepratio_floor;
      }

      if(fabs(actual_timestep-amesys->simOptions->fixedH) > 0.001*amesys->simOptions->fixedH)
      {
#ifdef AMEDEBUGw
         amefprintf(stdout,"Adjusting time step %14.8e => %14.8e\n", amesys->simOptions->fixedH, actual_timestep);
         amefprintf(stdout,"stepratio_floor=%d\n", stepratio_floor);
         amefprintf(stdout,"stepratio_ceil=%d\n", stepratio_ceil);
         amefprintf(stdout,"stepratio=%d\n", stepratio);
         amefprintf(stdout,"timerange=%14.8e\n", timerange);
#endif
      }
   }
   else
   {
      /* just single step from the last point in time when we were called */
      stepratio=1;
      actual_timestep = timerange;
   }

#if defined(AME_RESULT_FILE) && !defined(STANDALONESIMULATOR)
   if(amesys->resultFileStructPtr && !amesys->resultFileStructPtr->outoff)
   {
      next_print_time = GetNextPrintTime(&tinc, amesys->resultFileStructPtr->lastprinttime, amesys->simOptions->tFinal, amesys->simOptions->tInc, actual_timestep);
   }
#endif

#ifdef AMERT
   /* Allow changes of the stepratio - typically on RT platforms. */
   {
      double localstepratio=floor(IL_DFN_Model_Verification_step_ratio);
      if (localstepratio >= 1)
      {
         actual_timestep=timerange/localstepratio;
         stepratio = (int)localstepratio;
      }
   }
#endif
#ifdef STANDALONESIMULATOR
   FixedStepIntegrate(amesys,AME_NBOF_SOLVER_STATES,amesys->tlast,time,amesys->simOptions->tInc,amesys->states,
         amesys->yh,amesys->simOptions->fixedType,amesys->simOptions->fixedOrder,actual_timestep);
#else
	for (i=0; (i<stepratio) && (amesys->requestinterrupt == 0);i++)
   {
      /*Integrate one step */
	  if ( amesys->simOptions->fixedType == 1)
	  {
		DoAnABStep(amesys, amesys->numstates, amesys->simOptions->fixedOrder, &amesys->tlast, actual_timestep, amesys->states, amesys->yh);
	  }
	  else
	  {
		DoAnRKStep(amesys, amesys->numstates, amesys->simOptions->fixedOrder, &amesys->tlast, actual_timestep, amesys->states, amesys->yh);
	  }

#ifndef AMERT
      isTimeForPrint = amesys->resultFileStructPtr && (!amesys->resultFileStructPtr->outoff && ((amesys->tlast >= next_print_time) || ((next_print_time-amesys->tlast)/tinc < TIME_ROUNDOFF)));
      if(isTimeForPrint)
      {
#ifdef AME_PROCESS_TIME
         ProcessTime(1);
#endif
         SetIsPrinting(amesys);
         amesys->FuncEval(amesys, amesys->tlast, amesys->states, amesys->yh, NULL, &zero);
         ClearIsPrinting(amesys);
         amesys->OutputResults(amesys,amesys->tlast);
         next_print_time = GetNextPrintTime(&tinc, amesys->tlast, amesys->simOptions->tFinal, amesys->simOptions->tInc, actual_timestep);
      }
      else
#endif
      {
         amesys->FuncEval(amesys, amesys->tlast, amesys->states, amesys->yh, NULL, &zero);
      }
   }
#endif
   amesys->tlast = time;
}
#endif

static int ameOutputs(AMESIMSYSTEM *amesys, double timeARG, int numOutputs, double *outputARG)
{
   int theprintflag=1;
   double *dot;
   double *v;

   assert(amesys);

   v = amesys->v;
   dot = amesys->dotstates;

   if(numOutputs != amesys->numoutputs)
   {
      char error_message[256];
      sprintf(error_message, "AMEOutputs> Expected %d outputs but got %d\n", amesys->numoutputs, numOutputs);
      DisplayMessage(error_message);
      AmeExit(1);
   }

   if (!isdynrun_())
   {
      /* it is not a dynamic run (neither dynamic nor stabilizing + dynamic) */
      /* stabilizing has already been processed during Init.*/
      /*Exit */
      return 1;
   }

   if(timeARG < amesys->tlast)
   {
      DisplayMessage("trying to integrate backwards\n");
      return 0;
   }
#if(AME_MODEL_ISEXPLICIT == 1)
   amesys->t_end_of_time_slice = timeARG;
#ifndef AMERT
   if(!isfixedstepsolver_())
   {
      if(!IntegrateStep(amesys, amesys->tlast, timeARG))
      {
         DisplayMessage("IntegrateStep failed");
         return 0;
      }
      amesys->tlast = timeARG;
   }
   else
   {
      doAFixedStep(amesys, timeARG);
   }
#else
   doAFixedStep(amesys, timeARG);
#endif

#else
   if(!DIntegrateStep(amesys, AME_NBOF_EXPLICIT_STATE, amesys->tlast, timeARG, amesys->simOptions->tInc, amesys->states,
      amesys->dotstates, amesys->simOptions->hMax, AME_NBOF_SOLVER_STATES, amesys->iwork, amesys->simOptions->reltol,
      amesys->simOptions->abstol, amesys->simOptions->rStrtp, LIW, LRW, amesys->simOptions->statistics,
      amesys->simOptions->stabilOption, amesys->simOptions->iWrite, amesys->simOptions->minimalDiscont,
      amesys->internal_discont, Gis_constraint, &amesys->requestinterrupt))
   {
      DisplayMessage("DIntegrateStep failed");
      return 0;
   }

   amesys->tlast = timeARG;
#endif

#if (AME_NBOF_OUTPUTS > 0)
   memcpy(outputARG, amesys->outputs, amesys->numoutputs*sizeof(double) );
#endif

   return 1;
}

static AMESystemError AmesysComputeAtTstart(AMESIMSYSTEM *amesys, const double *theInputs, double *theOutputs)
{
   int jump_ret;
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_TSTART);

   if(res != AME_NO_ERROR) {
      /* Request not accepted */
      return res;
   }

   if( (jump_ret = setjmp(amesys->jump_env)) == 0) { /* try */
      if(amesys->simOptions->runType & 0x20) {
         /* fixed step solver */
#if(AME_MODEL_ISEXPLICIT == 1)
         if(!ameEvalTstartFixed(amesys, theInputs, theOutputs)) {
            res = AME_INITIALIZE_ERROR;
         }
#else
         amefprintf(stderr,"It is not possible to use a fixed step solver\nfor implicit systems.\n");
         res = AME_INITIALIZE_ERROR;
#endif
      }
      else {
         /* variable step solver */
         if(!ameEvalTstart(amesys, theInputs, theOutputs)) {
            res = AME_INITIALIZE_ERROR;
         }
      }

   }
   else { /* Catch AmeExit */
      res = AME_EXIT_ERROR;
   }

   /* Update state and result */
   res =  AmesysUpdateState(amesys, AME_CMD_TSTART, res);

   return res;
}

/***********************************************************
   Purpose    : Do a co-simulation step
   Author	  : J.Andre
   Created on : 2016 - 09 - 12
   Inputs	  : None
   Outputs	  : Error code
   Revision   :
************************************************************/
static AMESystemError AmesysStep(AMESIMSYSTEM *amesys, int stepType, const double t, const double *theInputs, double *theOutputs,
   const int doInterpol, const unsigned int *orderTab, const double **polyTab, const E_CS_Reset cs_reset)
{
   int jump_ret;
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_STEP);

   if(res != AME_NO_ERROR) {
      /* Request not accepted */
      return res;
   }

   if( (jump_ret = setjmp(amesys->jump_env)) == 0) { /* try */

#if defined(AME_MEMORY_ACCESS_RT_EXPORT)
#if (NB_WATCH_REAL_PARAM>0) || (NB_WATCH_INT_PARAM>0)
      RT_Set_Watch_Param(amesys);
#endif
#endif

#if defined(AME_COSIM) && (AME_NBOF_INPUTS > 0) && (!defined(AMERT))
      amesys->doInterpol = doInterpol;

      if(amesys->doInterpol) {
         stepType = 1;
         res = setPolyCosimSlave(amesys->csSlave, orderTab, polyTab);
      }
      else {
         res = setPolyCosimSlaveByInputs(amesys->csSlave, theInputs);
      }
#else
      amesys->doInterpol = 0;
#endif

      if(res == AME_NO_ERROR) {
         if(stepType == 0) {  /* Do a step */
            if(!ameOutputs(amesys, t, AME_NBOF_OUTPUTS, theOutputs)) {
               res = AME_STEP_ERROR;
            }
#ifndef AMERT
            amesys->input_discont = CheckIfColdStartNeed(amesys, theInputs, cs_reset);
            /* Need to do something here if no internal disc and disc printout */
            AddExtraPrintOut(amesys, amesys->tlast);
#endif
            if(amesys->doInterpol == 0) {
               if(!ameInputs(amesys, AME_NBOF_INPUTS, theInputs)) {
                  res = AME_STEP_ERROR;
               }
            }
         }
         else {  /* Do a step 2 */
#ifndef AMERT
            amesys->input_discont = CheckIfColdStartNeed(amesys, theInputs, cs_reset);

            /* Need to do something here if no internal disc and disc printout */
            res |= changePolynomialSlot(amesys->csSlave);
            AddExtraPrintOut(amesys, amesys->tlast);
            res |= changePolynomialSlot(amesys->csSlave);
#endif
            if(amesys->doInterpol == 0) {
               if(!ameInputs(amesys, AME_NBOF_INPUTS, theInputs)) {
                  res = AME_STEP_ERROR;
               }
            }

            if(!ameOutputs(amesys, t, AME_NBOF_OUTPUTS, theOutputs)) {
               res = AME_STEP_ERROR;
            }
#ifndef AMERT
            if(amesys->doInterpol != 0) {
               if( getInputsCosimSlave(amesys->csSlave, t, amesys->inputs) != AME_NO_ERROR ) {
                  res = AME_STEP_ERROR;
               }
            }
#endif
         }
         amesys->num_steps_taken++;
#ifndef AMERT
         res |= changePolynomialSlot(amesys->csSlave);
         res |= setTciCosimSlave(amesys->csSlave, t);
#endif
      }

#if defined(AME_MEMORY_ACCESS_RT_EXPORT)
#if (NB_WATCH_VAR>0)
      RT_Get_Watch_Var(amesys);
#endif
#endif
   }
   else { /* Catch AmeExit */
      res = AME_EXIT_ERROR;
   }

   /* Update state and result */
   res =  AmesysUpdateState(amesys, AME_CMD_STEP, res);

   return res;
}

/***********************************************************
   Purpose    : Set solver parameters
   Author	  : J.Andre
   Created on : 2016 - 09 - 09
   Inputs	  : None
   Outputs	  :
   Revision   :
************************************************************/
static AMESystemError AmesysSetSolverParam(AMESIMSYSTEM *amesys, const solverSettings *solver)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_SOLVER_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialyze Amesystem solver parameters */
      simOptSetSolverParam(amesys->simOptions,solver);
   }

   return res;
}

/***********************************************************
   Purpose    : Get solver parameters
   Author	  : J.Andre
   Created on : 2016 - 09 - 09
   Inputs	  : None
   Outputs	  :
   Revision   :
************************************************************/
static AMESystemError AmesysGetSolverParam(AMESIMSYSTEM *amesys, solverSettings *solver)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_SOLVER_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialyze Amesystem solver parameters */
      simOptGetSolverParam(amesys->simOptions, solver);
   }

   return res;
}

/***********************************************************
   Purpose    : Set run parameters
   Author	  : J.Andre
   Created on : 2016 - 09 - 09
   Inputs	  : None
   Outputs	  :
   Revision   :
************************************************************/
static AMESystemError AmesysSetSimParam(AMESIMSYSTEM *amesys, const simSettings *simOpt)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialyze Simulation parameters */
      simOptSetSimParam(amesys->simOptions,simOpt);
   }

   return res;
}

static AMESystemError AmesysGetSimParam(AMESIMSYSTEM *amesys, simSettings *simOpt)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Get Simulation parameters */
      simOptGetSimParam(amesys->simOptions, simOpt);
   }

   return res;
}

static AMESystemError AmesysSetSimItem(AMESIMSYSTEM *amesys, const int Id, const int enabled)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialyze Amesystem solver parameters */
      if(simOptSetOneOfSimParam(amesys->simOptions, Id, enabled) != 0) {
         res = AME_SETTINGS_ERROR;
      }
   }

   return res;
}

static AMESystemError AmesysGetSimItem(AMESIMSYSTEM *amesys, const int Id, int *enabled)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialyze Amesystem solver parameters */
      if(simOptGetOneOfSimParam(amesys->simOptions, Id, enabled) != 0) {
         res = AME_SETTINGS_ERROR;
      }
   }

   return res;
}

/***********************************************************
   Purpose    : Set run parameters
   Author	  : J.Andre
   Created on : 2016 - 09 - 09
   Inputs	  : None
   Outputs	  :
   Revision   :
************************************************************/
static AMESystemError AmesysSetStdOptions(AMESIMSYSTEM *amesys, const stdOptions *stdOpt)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialize standard parameters */
      simOptSetStdParam(amesys->simOptions,stdOpt);
   }

   return res;
}

static AMESystemError AmesysGetStdOptions(AMESIMSYSTEM *amesys, stdOptions *stdOpt)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Get standard parameter */
      simOptGetStdParam(amesys->simOptions, stdOpt);
   }

   return res;
}

static AMESystemError AmesysSetStdItem(AMESIMSYSTEM *amesys, const int Id, const int enabled)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialize standard parameter */
      if(simOptSetOneOfStdParam(amesys->simOptions, Id, enabled) != 0) {
         res = AME_SETTINGS_ERROR;
      }
   }

   return res;
}

static AMESystemError AmesysGetStdItem(AMESIMSYSTEM *amesys, const int Id, int *enabled)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialize standard parameter */
      if(simOptGetOneOfStdParam(amesys->simOptions, Id, enabled) != 0) {
         res = AME_SETTINGS_ERROR;
      }
   }

   return res;
}

static AMESystemError AmesysSetALAParam(AMESIMSYSTEM *amesys, const autoLAOptions *alaOpt)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Initialize standard parameters */
      simOptSetAlaParam(amesys->simOptions, alaOpt);
   }

   return res;
}

static AMESystemError AmesysGetALAParam(AMESIMSYSTEM *amesys, autoLAOptions *alaOpt)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      /* Get standard parameter */
      simOptGetAlaParam(amesys->simOptions, alaOpt);
   }

   return res;
}

/***********************************************************
   Purpose     : Turn off/on results
   Author	   : J.Andre
   Created on  : 2016 - 09 - 09
   Inputs	   :
      outoff   :  0 : result file off
                  1 : result file on
   Outputs	   :
   Revision    :
************************************************************/
static AMESystemError AmesysEnableResult(AMESIMSYSTEM *amesys, const int out)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      if(out) {
         amesys->simOptions->outoff = 0;
      }
      else {
         amesys->simOptions->outoff = 1;
      }
   }

   return res;
}

/***********************************************************
   Purpose     : Return the state of Amesystem
   Author	   : J.Andre
   Created     : 2016 - 09 - 05
   Inputs	   : None
   Outputs	   :
      state    : machine state
   Revision    :
************************************************************/
static unsigned int AmesysGetState(AMESIMSYSTEM *amesys)
{
   if(amesys) {
      return amesys->systemState;
   }
   else {
      return AMESTATE_IDLE;
   }
}

static AMESystemError AmesysGetModelInfo(unsigned int *numinputs, unsigned int *numoutputs, unsigned int *numstates, unsigned int *numimplicits)
{
   *numinputs = AME_NBOF_INPUTS;
   *numoutputs = AME_NBOF_OUTPUTS;
   *numstates = AME_NBOF_EXPLICIT_STATE;
   *numimplicits = AME_NBOF_IMPLICIT_STATE;

   return AME_NO_ERROR;
}

static AMESystemError AmesysGetModelPortName(const char **inputName[], const char **outputName[])
{
   *inputName = GinputVarTitles;
   *outputName = GoutputVarTitles;

   return AME_NO_ERROR;
}

static AMESystemError AmesysGetModelNumParam(unsigned int *numParam)
{
   *numParam = AME_NBOF_PARAMS;

   return AME_NO_ERROR;
}

static AMESystemError AmesysGetParamType(const int nbParam, const int idx[], E_ParamCType paramType[])
{
   AMESystemError res = AME_NO_ERROR;
   int i;

   for(i = 0; (i < nbParam) && (res == AME_NO_ERROR); i++) {
      if(i < AME_NBOF_PARAMS) {
         switch(GParamInfo[idx[i]].category) {
            case E_Int_Param:
               paramType[i] = E_CType_IntParam;
            break;
            case E_Text_Param:
               paramType[i] = E_CType_StringParam;
            break;
            default:
               paramType[i] = E_CType_DoubleParam;
            break;
         }
         return AME_NO_ERROR;
      }
      else {
         res = AME_PARAM_IDX_ERROR;
      }
   }

   return res;
}

static AMESystemError AmesysFindParamFromVar(const int nbParam, const int varIdx[], int paramIdx[], E_ParamCategory category[])
{
   AMESystemError res = AME_NO_ERROR;
   int idx, i;

   for(idx = 0; (idx < nbParam) && (res == AME_NO_ERROR); idx++) {
      res = AME_PARAM_IDX_ERROR;
      for(i = 0; i < AME_NBOF_PARAMS; i++) {
         if(GParamInfo[i].varIdx == varIdx[idx]) {
            paramIdx[idx] = i;
            category[idx] = GParamInfo[i].category;
            res = AME_NO_ERROR;
         }
      }
   }

   return res;
}

static AMESystemError AmesysGetIntParamValue(AMESIMSYSTEM *amesys, const int nbParam, const int idx[], int value[])
{
   AMESystemError res;
   int i;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_MODEL_PARAM);

   for(i = 0; (i < nbParam) && (res == AME_NO_ERROR); i++) {
      res = getIntParameter(amesys->pModel, idx[i], &value[i]);
   }

   return res;
}

static AMESystemError AmesysGetDoubleParamValue(AMESIMSYSTEM *amesys, const int nbParam, const int idx[], double value[])
{
   AMESystemError res;
   int i;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_MODEL_PARAM);

   for(i = 0; (i < nbParam) && (res == AME_NO_ERROR); i++) {
      res = getDoubleParameter(amesys->pModel, idx[i], &value[i]);
   }

   return res;
}

static AMESystemError AmesysGetStringParamValue(AMESIMSYSTEM *amesys, const int nbParam, const int idx[], const char* value[])
{
   AMESystemError res;
   int i;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_MODEL_PARAM);

   for(i = 0; (i < nbParam) && (res == AME_NO_ERROR); i++) {
      res = getStringParameter(amesys->pModel, idx[i], &value[i]);
   }

   return res;
}

static AMESystemError AmesysSetIntParamValue(AMESIMSYSTEM *amesys, const int nbParam, const int idx[], const int value[])
{
   AMESystemError res;
   int i;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM_TUNABLE);

   for(i = 0; (i < nbParam) && (res == AME_NO_ERROR); i++) {
      int isTunable;
      res = isParamTunable(amesys->pModel, idx[i], &isTunable);

      if(res ==  AME_NO_ERROR) {
         if(isTunable) {
            res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM_TUNABLE);
         }
         else {
            res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM);
         }
      }
      if(res ==  AME_NO_ERROR) {
         res = setIntParameter(amesys->pModel, idx[i], value[i]);
      }
      if(res == AME_NO_ERROR) {
         SignalInputChange();
         res = setParamAsUserDefined(amesys->pModel, idx[i]);
      }
   }

   return res;
}

static AMESystemError AmesysSetDoubleParamValue(AMESIMSYSTEM *amesys, const int nbParam, const int idx[], const double value[])
{
   AMESystemError res;
   int i;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM_TUNABLE);

   for(i = 0; (i < nbParam) && (res == AME_NO_ERROR); i++) {
      int isTunable;
      res = isParamTunable(amesys->pModel, idx[i], &isTunable);

      if(res ==  AME_NO_ERROR) {
         if(isTunable) {
            res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM_TUNABLE);
         }
         else {
            res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM);
         }
      }
      if(res ==  AME_NO_ERROR) {
         res = setDoubleParameter(amesys->pModel, idx[i], value[i]);
      }
      if(res == AME_NO_ERROR) {
         SignalInputChange();
         res = setParamAsUserDefined(amesys->pModel, idx[i]);
      }
   }

   return res;
}

static AMESystemError AmesysSetStringParamValue(AMESIMSYSTEM *amesys, const int nbParam, const int idx[], const char* value[])
{
   AMESystemError res;
   int i;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM_TUNABLE);

   for(i = 0; (i < nbParam) && (res == AME_NO_ERROR); i++) {
      int isTunable;
      res = isParamTunable(amesys->pModel, idx[i], &isTunable);

      if(res ==  AME_NO_ERROR) {
         if(isTunable) {
            res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM_TUNABLE);
         }
         else {
            res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM);
         }
      }
      if(res ==  AME_NO_ERROR) {
         res = setStringParameter(amesys->pModel,idx[i], value[i]);
      }
      if(res == AME_NO_ERROR) {
         res = setParamAsUserDefined(amesys->pModel, idx[i]);
      }
   }

   return res;
}

static AMESystemError AmesysGetDoubleGlobalParamValue(AMESIMSYSTEM *amesys, const int nbParam, const char* name[], double value[])
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_MODEL_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      int i;
      for(i = 0; i<nbParam; i++) {
         if(getGlobalParamValueByName(name[i], &value[i]) != no_error) {
            res = AME_GLOBAL_PARAMETER_ERROR;
            break;
         }
      }
   }

   return res;
}

static AMESystemError AmesysGetStringGlobalParamValue(AMESIMSYSTEM *amesys, const int nbParam, const char* name[], const char* value[])
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_GET_MODEL_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      int i;
      for(i = 0; i<nbParam; i++) {
         if(getTextGlobalParamValueByName(name[i], &value[i]) != no_error) {
            res = AME_GLOBAL_PARAMETER_ERROR;
            break;
         }
      }
   }

   return res;
}

static AMESystemError AmesysSetIntGlobalParamValue(AMESIMSYSTEM *amesys, const int nbParam, const char* name[], const int value[])
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      int i;
      for(i = 0; i<nbParam; i++) {
         if(ChangeOrAddIntGlobalParamValue(name[i], value[i], 1) != AME_NO_ERROR) {
            res = AME_GLOBAL_PARAMETER_ERROR;
            break;
         }
      }
   }

   return res;
}

static AMESystemError AmesysSetDoubleGlobalParamValue(AMESIMSYSTEM *amesys, const int nbParam, const char* name[], const double value[])
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      int i;
      for(i = 0; i<nbParam; i++) {
         if(ChangeOrAddRealGlobalParamValue(name[i], value[i], 1) != AME_NO_ERROR) {
            res = AME_GLOBAL_PARAMETER_ERROR;
            break;
         }
      }
   }

   return res;
}

static AMESystemError AmesysSetStringGlobalParamValue(AMESIMSYSTEM *amesys, const int nbParam, const char* name[], const char* value[])
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_MODEL_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      int i;
      for(i = 0; i<nbParam; i++) {
         if(ChangeOrAddTextGlobalParamValue(name[i], value[i], 1) != AME_NO_ERROR) {
            res = AME_GLOBAL_PARAMETER_ERROR;
            break;
         }
      }
   }

   return res;
}

static AMESystemError AmesysRequestRunInterrupt(AMESIMSYSTEM *amesys)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_REQ_RUN_INTERRUPT);

   if(res == AME_NO_ERROR) { /* Request accepted */
      amesys->requestinterrupt = 1;

	   /* Update state and result */
	   res =  AmesysUpdateState(amesys, AME_CMD_REQ_RUN_INTERRUPT, res);
   }

   return res;
}

static AMESystemError AmesysSetFinalTime(AMESIMSYSTEM *amesys, const double finaltime)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      amesys->simOptions->tFinal = finaltime;
   }

   return res;
}

static AMESystemError AmesysSetInitTime(AMESIMSYSTEM *amesys, const double inittime)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      amesys->simOptions->tStart = inittime;
   }

   return res;
}

static AMESystemError AmesysSetPrintInterval(AMESIMSYSTEM *amesys, const double tInc)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      amesys->simOptions->tInc = tInc;
   }

   return res;
}

static AMESystemError AmesysSetLogger( int (*newameInternalfprintf)(FILE *fp, const char *fmt, va_list ap) )
{
   ameInstallFprintf(newameInternalfprintf);
   return AME_NO_ERROR;
}

static AMESystemError AmesysSetInputDir(AMESIMSYSTEM *amesys, const char *inputDir)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_ENV);

   if(res == AME_NO_ERROR) { /* Request accepted */
      AmeSetInputDir(amesys, inputDir);
   }

   return res;
}

static AMESystemError AmesysSetOutputDir(AMESIMSYSTEM *amesys, const char *outputDir)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_ENV);

   if(res == AME_NO_ERROR) { /* Request accepted */
      AmeSetOutputDir(amesys, outputDir);
   }

   return res;
}

static AMESystemError AmesysSetBaseFilesName(AMESIMSYSTEM *amesys, const char *baseName, const char* extension)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_ENV);

   if(res == AME_NO_ERROR) { /* Request accepted */
      AmeSetModelBaseName(amesys, baseName, extension);
   }

   return res;
}

static AMESystemError AmesysSetResultFilesName(AMESIMSYSTEM *amesys, const char *outName)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_ENV);

   if(res == AME_NO_ERROR) { /* Request accepted */
      AmeSetResultFileName(amesys, outName);
   }

   return res;
}

/* To ensure compliancy with old template and entry points */
static AMESystemError AmesysSetParamAsInitModel(AMESIMSYSTEM *amesys,
                  double time,
                  double PrintInterval,
                  double MaxTimeStep,
                  double tolerance,
                  int errCtrl,
                  int writeLevel,
                  int extraDisconPrints,
                  int runStats,
                  int runType,
                  int thesolvertype)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);
   res |= AmesysControlRequest(amesys, AME_CMD_SET_SOLVER_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      SIMOptions *sim_options = amesys->simOptions;

      solverSettings solver;
      simSettings sim;
      stdOptions std;

      solver.integType =  0; /* Variable solver */
      solver.variable.hMax = MaxTimeStep;
      solver.variable.tol = tolerance;
      solver.variable.errorType = errCtrl;

      simOptSetSolverParam(amesys->simOptions, &solver);

      sim.tStart = time;
      sim.tFinal = amesys->simOptions->tFinal;
      sim.simOpt = 0;

      if(runType & 0x01) {
         sim.simOpt |= SIMOPT_SIM_CONTINUATION_RUN;
      }
      if(runType & 0x02) {
         sim.simOpt |= SIMOPT_SIM_USE_FINAL_VALUES;
      }
      if(writeLevel != 2) {
         sim.simOpt |= SIMOPT_SIM_MONITOR_TIME;
      }
      if(runStats) {
         sim.simOpt |= SIMOPT_SIM_STATISTICS;
      }

      if(PrintInterval <= 0) {
         sim.tInc = -PrintInterval;
         amesys->simOptions->outoff = 1;
      }
      else {
         sim.tInc = PrintInterval;
         amesys->simOptions->outoff = 0;
      }

      simOptSetSimParam(amesys->simOptions, &sim);

      std.simMode = ((runType & 0x0c) >> 2);
      std.stdOpt = 0;

      if(extraDisconPrints) {
         std.stdOpt |= SIMOPT_STD_DISC_PRINTOUT;
      }
      if(runType & 0x10) {
         std.stdOpt |= SIMOPT_STD_HOLD_INPUTS;
      }
      if(amesys->simOptions->stabilOption & 0x01) {
         std.stdOpt |= SIMOPT_STD_LOCK_STATES;
      }
      if(amesys->simOptions->stabilOption & 0x02) {
         std.stdOpt |= SIMOPT_STD_DIAGNOSTICS;
      }
      if(thesolvertype) {
         std.stdOpt |= SIMOPT_STD_CAUTIOUS;
      }
      if(amesys->simOptions->minimalDiscont) {
         std.stdOpt |= SIMOPT_STD_MIN_DISC_HANDLING;
      }
      if(runType & 0x100) {
         std.stdOpt |= SIMOPT_STD_DISABLE_OPTIMAZED;
      }
      if(sim_options->activityIndex & 0x01) {
         std.stdOpt |= SIMOPT_STD_ACTIVITY;
      }
      if(sim_options->activityIndex & 0x02) {
         std.stdOpt |= SIMOPT_STD_POWER;
      }
      if(sim_options->activityIndex & 0x04) {
         std.stdOpt |= SIMOPT_STD_ENERGY;
      }
      simOptSetStdParam(amesys->simOptions, &std);
   }
   return res;
}

/* To ensure compliancy with old template and entry points */
static AMESystemError AmesysSetParamAsFixedStep(AMESIMSYSTEM *amesys,
                                       double start_time, int run_type, int solver_type,
                                       int runge_kutta_order, double fixed_h, double printinterval)
{
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_SET_RUN_PARAM);
   res |= AmesysControlRequest(amesys, AME_CMD_SET_SOLVER_PARAM);

   if(res == AME_NO_ERROR) { /* Request accepted */
      solverSettings solver;

      res = AME_NO_ERROR;

      solver.integType = 1; /* Fixed solver */
      solver.fixed.fixedH = fixed_h;
      solver.fixed.fixedOrder = runge_kutta_order;
      solver.fixed.fixedType = solver_type;

      simOptSetSolverParam(amesys->simOptions, &solver);
      amesys->simOptions->tStart = start_time;

      if(printinterval <= 0) {
         amesys->simOptions->outoff = 1;
         amesys->simOptions->tInc = -printinterval;
      }
      else {
         amesys->simOptions->outoff = 0;
         amesys->simOptions->tInc = printinterval;
      }
      simOptSetOneOfSimParam(amesys->simOptions, SIMOPT_SIM_CONTINUATION_RUN, run_type & 0x01);
      simOptSetOneOfSimParam(amesys->simOptions, SIMOPT_SIM_USE_FINAL_VALUES, (run_type & 0x02)>>1);
   }
   return res;
}

#ifndef AME_COSIM

static AMESystemError AmesysInitME(AMESIMSYSTEM *amesys, int withAssembly)
{
   AMESystemError res = AME_NO_ERROR;
   int jump_ret;

   res = AmesysControlRequest(amesys, AME_CMD_INITIALIZE);

   if(res != AME_NO_ERROR) {
      /* Request not accepted */
      return res;
   }

   /* Load parameters */
   res = Input(amesys);

   /* Set initial values */
   modelSetInitValues(amesys->pModel, amesys->states, amesys->discrete_states);

   if(res == AME_NO_ERROR) {
      if( (jump_ret = setjmp(amesys->jump_env)) == 0) { /* try */

         setstarttime_(amesys->simOptions->tStart);
         setfinaltime_(amesys->simOptions->tFinal);

         amesys->first_call = 1;  /* should this be done or not ?*/
         amesys->internal_discont = 1;

         amesys->tlast = TLAST_MIN;

         memset(amesys->ecount,0,amesys->numstates*sizeof(int));
         memset(amesys->dotstates,0,amesys->numstates*sizeof(double));

         PreInitialize(amesys,amesys->states);

#ifndef AME_INPUT_IN_MEMORY
         if( NeedReloadInputFiles() != 0 )
         {
            ClearGPs();
            Input(amesys);
            /* Set initial values */
            modelSetInitValues(amesys->pModel, amesys->states, amesys->discrete_states);
            ClearReloadedFiles();
         }
#endif

         Initialize(amesys,amesys->states);

         OverloadStatesWithRegister(amesys, amesys->states, SVREGISTER_DEFAULT);

         if(withAssembly) {
            doAssembly(amesys);
         }
         amesys->tlast = getstarttime_();
#ifdef AME_PROCESS_TIME
         /* Initialization of time timers */
         ProcessTime(0);
#endif
      }
      else { /* Catch AmeExit */
         res = AME_EXIT_ERROR;
      }
   }

   /* Update state and result */
   res =  AmesysUpdateState(amesys, AME_CMD_INITIALIZE, res);

   if(res == AME_NO_ERROR) {
      /* Go in Run state: simulate acknowledgment of evaluation at t start command */
      res =  AmesysUpdateState(amesys, AME_CMD_TSTART, res);

#if defined(AME_MEMORY_ACCESS_RT_EXPORT)
#if (NB_WATCH_VAR>0)
         RT_Get_Watch_Var(amesys);
#endif
#endif
   }

   return res;
}

static AMESystemError AmesysFuncEvalME(AMESIMSYSTEM *amesys, double t, double *y, double *yprime, double *delta, int *flag)
{
   int jump_ret;
   AMESystemError res;

   SetGlobalSystem(amesys);
   res = AmesysControlRequest(amesys, AME_CMD_FUNCEVAL);

   if(res != AME_NO_ERROR) {
      /* Request not accepted */
      return res;
   }

   if( (jump_ret = setjmp(amesys->jump_env)) == 0) { /* try */
      amesys->doInterpol = 0;
      localFuncEval(amesys, t, y, yprime, delta, flag);
   }
   else { /* Catch AmeExit */
      res = AME_EXIT_ERROR;
   }

   /* Update state and result */
   res =  AmesysUpdateState(amesys, AME_CMD_FUNCEVAL, res);
   return res;
}

#endif

/****************************/

#define SYSNME DFN_Model_Verification_

#if defined(STANDALONESIMULATOR) || defined(OLS)
#include "ame_standalone_simulator.h"

#elif defined(FMICS1)
#include "ame_fmics1.h"
#elif defined(FMICS2)
#include "ame_fmics2.h"
#elif defined(FMICS3)
#include "ame_fmics3.h"
#elif defined(FMIME1) || defined(FMIME2)
#if(AME_MODEL_ISEXPLICIT == 0)
#error "FMI for model exchange is not allowed for implicit model."
#elif defined(AMERT)
#error "FMU for real-time is not allowed for model exchange."
#elif defined(FMIME1)
#include "ame_fmime1.h"
#else
#include "ame_fmime2.h"
#endif
#elif defined(FMIX)
#include "ame_user_cosim.h"

#elif defined(AMEUSERCOSIM)
#include "ame_user_cosim.h"

#elif defined(AME_CS_SIMULINK)
#include "ame_simulink_cosim.h"

#elif defined(AME_ME_SIMULINK)
#include "ame_simulink_me.h"

#elif defined(AME_CS_ADAMS)
#include "ame_adams_cosim.h"

#elif defined(AME_ME_ADAMS)
#include "adams_cont.h"

#elif defined(AME_CS_MOTION)
#include "ame_motion_cosim.h"

#elif defined(AME_ME_MOTION)
#include "ame_motion_me.h"

#elif defined(DISCRETEPART)
#include "ame_discrete_part.h"

#elif defined(GEN_COSIM)
#include "gen_cosim.h"

#elif defined(AME_CS_SIMULINK_SCANER)
#include "ame_simulink_scaner.h"

#else
#error "Unknown interface defined. Cannot generate Amesim model code."
#endif
