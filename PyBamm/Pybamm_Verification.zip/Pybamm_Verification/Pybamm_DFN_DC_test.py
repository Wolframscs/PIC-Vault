import os
import pybamm
import numpy as np
import pandas as pd
from Pybamm_Para import getParameterValues

# By modifying the amplification parameter C, 
# the discharge curves under different amplification ratios are simulated.
I_1C=100     
C=1
Current=I_1C*C

# load model, from pybamm
options = {"cell geometry": "arbitrary", "thermal": "isothermal","contact resistance": "true"}
model = pybamm.lithium_ion.DFN(options)
# Step 1: Parameter replacement
param= getParameterValues()
parameter_values = pybamm.ParameterValues(param)
parameter_values["Current function [A]"]=Current
I=parameter_values["Current function [A]"]
print(f"Current function= {I} A")
parameter_values.process_model(model)
geometry = model.default_geometry
parameter_values.process_geometry(geometry)

# Step 2: Meshing and discretisation
var_pts = {"x_n": 15, "x_s": 13, "x_p": 15, "r_n": 10, "r_p": 10}
mesh = pybamm.Mesh(geometry, model.default_submesh_types, var_pts)
disc = pybamm.Discretisation(mesh, model.default_spatial_methods)
disc.process_model(model)

# Step 3: Solver solve
# create a PyBaMM `Simulation`, which is used to process and solve the model
# solver_accuracy = pybamm.IDAKLUSolver(rtol=1e-4, atol=1e-6)
solver_accuracy = pybamm.IDAKLUSolver(rtol=1e-8, atol=1e-12)
simulation = pybamm.Simulation(model, parameter_values=parameter_values, solver=solver_accuracy)
simulation.solve([0, 1000])

# Step 4: Post-processing
solution = simulation.solution
t_post=solution.t
t_post=np.linspace(0, int(max(t_post)), int(max(t_post))+1)
print(f"Simulation ended at time: {int(max(t_post))}")
# Get voltage data
voltage = solution["Voltage [V]"]
voltage_values=voltage.entries
print(f"Voltage at the last second: {voltage_values[-1]:.4f} V")


# Post-processing
Current=solution["Current variable [A]"](t_post)
voltage = solution["Terminal voltage [V]"](t_post)
OCV=solution["Battery open-circuit voltage [V]"](t_post)
data = {
    "Time [s]": t_post,
    "Current [A]": Current,
    "Voltage [V]": voltage,
    "Open-circuit voltage [V]": OCV,
}
df = pd.DataFrame(data)
# Get the directory path of the current Python file
current_script_dir = os.path.dirname(os.path.abspath(__file__))
# Generate the full CSV file save path (current script directory + filename)
csv_file_path = os.path.join(current_script_dir, 'Pybamm_Data_4C_re.csv')
df.to_csv(csv_file_path, index=False)
print(f"File saved to: {csv_file_path}")  # Print the save path for confirmation
# solution.plot()



