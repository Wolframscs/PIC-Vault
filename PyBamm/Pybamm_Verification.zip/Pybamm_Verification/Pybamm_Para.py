import os
import numpy as np
import pybamm



# *******************************************************************************************
# ****************************** Used Key Parameters ****************************************
# *******************************************************************************************
# UNIVERSAL_PARAMETERS
pole_H=2                          # Pole height [m]
pole_W=3                          # Pole width [m]
brug = 1.5                        # Bruggeman coefficient
t_plus = 0.363                    # Cation transfer coefficient
dlnfdlnc = 0                      # activation coefficient
i_1C = 100                        # 1C constant current [A] and nominal capacity [Ah]
F =96485.3329                     # Faraday constant [C/mol]
R =8.3145                         # Universal gas constant [J/(mol·K)]

# ANODE_PARAMETERS
L_neg = 100e-6                   # Anode thickness [m]
Ds_neg = 3.9e-14                 # Anode diffusion coefficient [m²/s]
rp_neg = 12.5e-6                 # Anode particle radius [m]
eps_e_neg = 0.357                # Anode electrode porosity,electrolyte volume fraction
eps_s_neg = 1-eps_e_neg-0.172    # Anode active material volume fraction
eps_s_neg_re = 1-eps_e_neg       # Anode active material volume fraction
as_neg = 3*(eps_s_neg)/rp_neg    # Anode  specific surface area [1/m]
sigma_neg = 100                  # Anode electrode conductivity [S/m]
sigma_neg_eff=sigma_neg*eps_s_neg**brug      # Effective Anode electrode conductivity [S/m]
cs_max_neg = 26390               # Anode particle maximum concentration [mol/m³]
cs0_neg = 12620.55045            # Anode particle initial concentration [mol/m³]
alpha_neg = 0.5                  # Anode  charge transfer coefficient
k_neg_norm = 1.5e-10             # Anode reaction rate constant 

# SEPARATOR_PARAMETERS
L_sep = 52e-6                    # Separator length [m]
eps_e_sep = 0.9                  # Separator electron porosity
# CATHODE_PARAMETERS
L_pos = 183e-6                   # Cathode thickness [m]
Ds_pos = 1e-13                   # Cathode diffusion coefficient [m²/s]
rp_pos = 8e-6                    # Cathode particle radius [m]
eps_e_pos = 0.444                # Cathode electrode porosity,electrolyte volume fraction
eps_s_pos = 1-eps_e_pos-0.259    # Cathode active material volume fraction
eps_s_pos_re = 1-eps_e_pos       # Cathode active material volume fraction
as_pos = 3*(eps_s_pos)/rp_pos    # Cathode  specific surface area [1/m]
sigma_pos = 3.8                  # Cathode electrode conductivity [S/m]
sigma_pos_eff=sigma_pos*eps_s_pos**brug      # Effective Cathode electrode conductivity [S/m]
cs_max_pos = 22860               # Cathode particle maximum concentration [mol/m³]
cs0_pos = 12335.36981            # Cathode particle initial concentration [mol/m³]
alpha_pos = 0.5                  # Cathode  charge transfer coefficient
k_pos_norm = 1.31e-13            # Cathode reaction rate constant 
# ELECTROLYTE_PARAMETERS
D_e = 7.5e-11                    # Electrolyte diffusion coefficient [m²/s]
sigma_e=0.3                     # Electrolyte conductivity [S/m]
c_e0 = 2000                     # Electrolyte initial concentration [mol/m³]
# Cell temperature parameters
Tenv = 298.15                               # Ambient temperature [K]
Ini_Temp = 298.15                           # Initial temperature [K]
T_ref = 298.15                              # Reference temperature [K]
print("sigma_neg_eff=",sigma_neg_eff)
print("sigma_pos_eff=",sigma_pos_eff)


# =============================================================================
# =====vMaintain the integrity of the model; unused parameters.================
# =============================================================================
# Cell design geometric parameters
neg_CC_Th = 5e-06/2                         # Negative current collector thickness (copper foil) [m]
pos_CC_Th = 13e-06/2                        # Positive current collector thickness (aluminum foil) [m]
# Cell parameter
cell_Mass = 2.236                           # Cell mass [kg]
cell_Cp = 1075.0                            # Cell specific heat capacity [J/(kg·K)]
equiv_Conv_HTC = 300.0                      # Equivalent convective heat transfer coefficient [W/(m²·K)], liquid cooling
# The kinetic parameters obtained through parameter identification and Electrode balancing parameters by optimization
cooling_Surface_Area = 1                    # Cell cooling surface area [m²], liquid cooling
cell_Emis = 0.95                            # Cell emissivity
cellThermalExpansion = 1.1e-06              # Cell thermal expansion coefficient [m/K]
# Current collector thermal parameters
neg_CC_Conduct = 5.998e7                    # Negative current collector conductivity (copper) [S/m]
pos_CC_Conduct = 3.774e7                    # Positive current collector conductivity (aluminum) [S/m]
neg_CC_Density = 8960.0                     # Negative current collector density (copper) [kg/m³]
pos_CC_Density = 2700.0                     # Positive current collector density (aluminum) [kg/m³]
neg_CC_Cp = 385.0                           # Negative current collector specific heat capacity [J/(kg·K)]
pos_CC_Cp = 897.0                           # Positive current collector specific heat capacity [J/(kg·K)]
neg_CC_Thermal_Conduct = 401.0              # Negative current collector thermal conductivity [W/(m·K)]
pos_CC_Thermal_Conduct = 237.0              # Positive current collector thermal conductivity [W/(m·K)]

# Electrode and separator thermal parameters
sep_Cp = 1080.2                             # Separator specific heat capacity [J/(kg·K)]
sep_Density = 2470.0                        # Separator density [kg/m³]
sep_Thermal_Conduct = 0.334                 # Separator thermal conductivity [W/(m·K)]
neg_Elec_Cp = 1080.2                        # Negative electrode specific heat capacity [J/(kg·K)]
neg_Elec_Density = 2470.0                   # Negative electrode density [kg/m³]
neg_Elec_Thermal_Conduct = 1.04             # Negative electrode thermal conductivity [W/(m·K)]
pos_Elec_Cp = 1080.2                        # Positive electrode specific heat capacity [J/(kg·K)]
pos_Elec_Density = 2470.0                   # Positive electrode density [kg/m³]
pos_Elec_Thermal_Conduct = 1.58             # Positive electrode thermal conductivity [W/(m·K)]

# Electrode mechanical parameters
neg_Elec_Young = 15e9                       # Negative electrode Young's modulus [Pa]
pos_Elec_Young = 375e9                      # Positive electrode Young's modulus [Pa]
neg_Elec_Poisson = 0.3                      # Negative electrode Poisson's ratio
pos_Elec_Poisson = 0.2                      # Positive electrode Poisson's ratio
neg_Elec_PartialMolar_Vol = 3.1e-06         # Negative electrode partial molar volume [m³/mol]
pos_Elec_PartialMolar_Vol = -7.28e-07       # Positive electrode partial molar volume [m³/mol]

# LAM parameters
neg_Elec_LAM_Exp = 2.0                      # Negative electrode LAM exponential term
pos_Elec_LAM_Exp = 2.0                      # Positive electrode LAM exponential term
neg_Elec_LAM_Prop = 0.0                     # Negative electrode LAM proportional term [s⁻¹]
pos_Elec_LAM_Prop = 2.78e-13                # Positive electrode LAM proportional term [s⁻¹]

# Electrode crack parameters
paris_Law_B = 1.12                          # Paris law constant b
paris_Law_M = 2.2                           # Paris law constant m
neg_Elec_InitialCrackL = 2e-08              # Negative electrode initial crack length [m]
pos_Elec_InitialCrackL = 2e-08              # Positive electrode initial crack length [m]
neg_Elec_InitialCrackW = 1.5e-08            # Negative electrode initial crack width [m]
pos_Elec_InitialCrackW = 1.5e-08            # Positive electrode initial crack width [m]
neg_Elec_CrackDensity = 3.18e15             # Negative electrode crack density [m⁻²]
pos_Elec_CrackDensity = 3.18e15             # Positive electrode crack density [m⁻²]
neg_Elec_CriticalStress = 60e6              # Negative electrode critical stress [Pa]
pos_Elec_CriticalStress = 375e6             # Positive electrode critical stress [Pa]




# *******************************************************************************************
# ******************************Material Parameter Funcation Definition**********************
# *******************************************************************************************
def graphite_Electrolyte_ExchangeCurrentDensity(c_e, c_s_surf, c_s_max, T):
    """
    Graphite electrolyte exchange current density of LiPF6 in 3:7 EC:EMC (liquid electrolyte, Li-ion battery)
    """
    # kneg*(cl*1[m^3/mol])^alpha_neg*((cs_max_neg-cse)*1[m^3/mol])^alpha_neg*(cse*1[m^3/mol])^alpha_neg
    j0=k_neg_norm*(c_e)**alpha_neg*((c_s_max-c_s_surf))**alpha_neg*(c_s_surf)**alpha_neg
    return j0*F

def LFP_Electrolyte_ExchangeCurrentDensity(c_e, c_s_surf, c_s_max, T):
    # kpos*(cl*1[m^3/mol])^alpha_pos*((cs_max_pos-cse)*1[m^3/mol])^alpha_pos*(cse*1[m^3/mol])^alpha_pos
    j0=k_pos_norm*(c_e)**alpha_pos*((c_s_max-c_s_surf))**alpha_pos*(c_s_surf)**alpha_pos
    return j0*F

path, _ = os.path.split(os.path.abspath(__file__))
# Load data in the appropriate format, OCP data and dUdT data
Eeq_neg = pybamm.parameters.process_1D_data(
    "Eeq_neg.csv", path=path                    # Negative electrode OCP data file    
)
Eeq_pos = pybamm.parameters.process_1D_data(
    "Eeq_pos.csv", path=path                    # Positive electrode OCP data file    
)

# Interpolating function, interpolating Method have 'Linear', 'Cubic', and 'Pchip' 
def neg_Elec_OCP(sto):                         # Negative electrode OCP interpolation function with SOC
    name, (x, y) = Eeq_neg
    return pybamm.Interpolant(x, y, sto, name=name, interpolator="linear")

def pos_Elec_OCP(sto):                         # Positive electrode OCP interpolation function with SOC
    name, (x, y) = Eeq_pos
    return pybamm.Interpolant(x, y, sto, name=name, interpolator="linear")


# Call dict via a function to avoid errors when editing in place
def getParameterValues():
    """
    Design parameters for the NBC18 cell
    """
    return {
        "chemistry": "lithium_ion",
        # cell
        "Negative current collector thickness [m]": neg_CC_Th,
        "Negative electrode thickness [m]": L_neg,
        "Separator thickness [m]": L_sep,
        "Positive electrode thickness [m]": L_pos,
        "Positive current collector thickness [m]": pos_CC_Th,
        "Electrode height [m]": pole_H,
        "Electrode width [m]": pole_W,
        "Cell cooling surface area [m2]": cooling_Surface_Area,
        "Cell volume [m3]": 1,
        "Cell mass [kg]": cell_Mass,
        "Cell specific heat capacity [J.kg-1.K-1]": cell_Cp,
        "Cell emissivity": cell_Emis,
        "Cell thermal expansion coefficient [m.K-1]": cellThermalExpansion,
        "Negative current collector conductivity [S.m-1]": neg_CC_Conduct,  # Copper conductivity
        "Positive current collector conductivity [S.m-1]": pos_CC_Conduct,  # Aluminum conductivity
        "Negative current collector density [kg.m-3]": neg_CC_Density,
        "Positive current collector density [kg.m-3]": pos_CC_Density,
        "Negative current collector specific heat capacity [J.kg-1.K-1]": neg_CC_Cp,
        "Positive current collector specific heat capacity [J.kg-1.K-1]": pos_CC_Cp,
        "Negative current collector thermal conductivity [W.m-1.K-1]": neg_CC_Thermal_Conduct,
        "Positive current collector thermal conductivity [W.m-1.K-1]": pos_CC_Thermal_Conduct,
        "Nominal cell capacity [A.h]": i_1C,
        "Current function [A]": i_1C,
        "Contact resistance [Ohm]": 0,
        # negative electrode
        "Negative electrode conductivity [S.m-1]": sigma_neg_eff,
        "Maximum concentration in negative electrode [mol.m-3]": cs_max_neg,
        "Negative particle diffusivity [m2.s-1]": Ds_neg,
        "Negative electrode OCP [V]": neg_Elec_OCP,
        "Negative electrode porosity": eps_e_neg,
        "Negative electrode active material volume fraction": eps_s_neg,
        "Negative particle radius [m]": rp_neg,
        "Negative electrode surface area to volume ratio [m-1]":as_neg ,
        "Negative electrode Bruggeman coefficient (electrolyte)": brug,
        "Negative electrode Bruggeman coefficient (electrode)": 0,
        "Negative electrode charge transfer coefficient": alpha_neg,
        "Negative electrode double-layer capacity [F.m-2]": 0,
        "Negative electrode exchange-current density [A.m-2]": graphite_Electrolyte_ExchangeCurrentDensity,
        "Negative electrode density [kg.m-3]": neg_Elec_Density,
        "Negative electrode specific heat capacity [J.kg-1.K-1]": neg_Elec_Cp,
        "Negative electrode thermal conductivity [W.m-1.K-1]": neg_Elec_Thermal_Conduct,
        "Negative electrode OCP entropic change [V.K-1]": 0,
        "Negative electrode Poisson's ratio": neg_Elec_Poisson,
        "Negative electrode Young's modulus [Pa]": neg_Elec_Young,
        "Negative electrode reference concentration for free of deformation [mol.m-3]": 0.0,
        "Negative electrode partial molar volume [m3.mol-1]": neg_Elec_PartialMolar_Vol,
        "Negative electrode volume change": 0.0,  # Simplified to 0, avoid complex function
        "Negative electrode initial crack length [m]": neg_Elec_InitialCrackL,
        "Negative electrode initial crack width [m]": neg_Elec_InitialCrackW,
        "Negative electrode number of cracks per unit area [m-2]": neg_Elec_CrackDensity,
        "Negative electrode Paris' law constant b": paris_Law_B,
        "Negative electrode Paris' law constant m": paris_Law_M,
        "Negative electrode cracking rate": 0.0,  # Simplified to 0, avoid complex function
        "Negative electrode activation energy for cracking rate [J.mol-1]": 0.0,
        "Negative electrode LAM constant proportional term [s-1]": neg_Elec_LAM_Prop,
        "Negative electrode LAM constant exponential term": neg_Elec_LAM_Exp,
        "Negative electrode critical stress [Pa]": neg_Elec_CriticalStress,
        # positive electrode
        "Positive electrode conductivity [S.m-1]": sigma_pos_eff,
        "Maximum concentration in positive electrode [mol.m-3]": cs_max_pos,
        "Positive particle diffusivity [m2.s-1]": Ds_pos,
        "Positive electrode OCP [V]": pos_Elec_OCP,
        "Positive electrode porosity": eps_e_pos,
        "Positive electrode active material volume fraction": eps_s_pos,
        "Positive particle radius [m]": rp_pos,
        "Positive electrode surface area to volume ratio [m-1]":as_pos ,
        "Positive electrode Bruggeman coefficient (electrolyte)": brug,
        "Positive electrode Bruggeman coefficient (electrode)": 0,
        "Positive electrode charge transfer coefficient": alpha_pos,
        "Positive electrode double-layer capacity [F.m-2]": 0,
        "Positive electrode exchange-current density [A.m-2]": LFP_Electrolyte_ExchangeCurrentDensity,
        "Positive electrode density [kg.m-3]": pos_Elec_Density,
        "Positive electrode specific heat capacity [J.kg-1.K-1]": pos_Elec_Cp,
        "Positive electrode thermal conductivity [W.m-1.K-1]": pos_Elec_Thermal_Conduct,
        "Positive electrode OCP entropic change [V.K-1]": 0,
        "Positive electrode Poisson's ratio": pos_Elec_Poisson,
        "Positive electrode Young's modulus [Pa]": pos_Elec_Young,
        "Positive electrode reference concentration for free of deformation [mol.m-3]": 0.0,
        "Positive electrode partial molar volume [m3.mol-1]": pos_Elec_PartialMolar_Vol,
        "Positive electrode volume change": 0.0,  # Simplified to 0, avoid complex function
        "Positive electrode initial crack length [m]": pos_Elec_InitialCrackL,
        "Positive electrode initial crack width [m]": pos_Elec_InitialCrackW,
        "Positive electrode number of cracks per unit area [m-2]": pos_Elec_CrackDensity,
        "Positive electrode Paris' law constant b": paris_Law_B,
        "Positive electrode Paris' law constant m": paris_Law_M,
        "Positive electrode cracking rate": 0.0,  # Simplified to 0, avoid complex function
        "Positive electrode activation energy for cracking rate [J.mol-1]": 0.0,
        "Positive electrode LAM constant proportional term [s-1]": pos_Elec_LAM_Prop,
        "Positive electrode LAM constant exponential term": pos_Elec_LAM_Exp,
        "Positive electrode critical stress [Pa]": pos_Elec_CriticalStress,
        # separator
        "Separator porosity": eps_e_sep,
        "Separator Bruggeman coefficient (electrolyte)": brug,
        "Separator density [kg.m-3]": sep_Density,
        "Separator specific heat capacity [J.kg-1.K-1]": sep_Cp,
        "Separator thermal conductivity [W.m-1.K-1]": sep_Thermal_Conduct,
        # electrolyte
        "Initial concentration in electrolyte [mol.m-3]": c_e0,
        "Cation transference number": t_plus,
        "Thermodynamic factor":dlnfdlnc,
        "Electrolyte diffusivity [m2.s-1]": D_e,
        "Electrolyte conductivity [S.m-1]": sigma_e,
        # experiment
        "Reference temperature [K]": T_ref,
        "Total heat transfer coefficient [W.m-2.K-1]": equiv_Conv_HTC,
        "Ambient temperature [K]": Tenv,
        "Number of electrodes connected in parallel to make a cell": 1.0,
        "Number of cells connected in series to make a battery": 1.0,
        "Lower voltage cut-off [V]": 2.5,
        "Upper voltage cut-off [V]": 4.25,
        "Open-circuit voltage at 0% SOC [V]": 3.325,
        "Open-circuit voltage at 100% SOC [V]": 4.088,
        "Initial concentration in negative electrode [mol.m-3]": cs0_neg,
        "Initial concentration in positive electrode [mol.m-3]": cs0_pos,
        "Initial temperature [K]": Ini_Temp,
        # citations
        "citations": ["NBC18_Para"],
    }


